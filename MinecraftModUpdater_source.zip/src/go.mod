module MinecraftModUpdater

go 1.22.2
