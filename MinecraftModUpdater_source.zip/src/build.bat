@echo off
setlocal

:: ─────────────────────────────────────────────
::  MinecraftModUpdater — build script
::  Usage:  build.bat [version]
::  Example: build.bat 1.2.0
::  Default version: 1.0.0
:: ─────────────────────────────────────────────

set VERSION=%~1
if "%VERSION%"=="" set VERSION=1.0.0

set GOARCH=amd64
set GOOS=windows
set CGO_ENABLED=0

echo.
echo  Building MinecraftModUpdater v%VERSION%
echo  ─────────────────────────────────────────

:: Step 1 — embed icon (skip if app.syso already exists)
if exist app.syso goto build
echo  [1/2] Embedding icon...
where windres >nul 2>&1
if %ERRORLEVEL%==0 (
    windres -i app.rc -O coff -o app.syso
    goto build
)
where rsrc >nul 2>&1
if %ERRORLEVEL%==0 (
    rsrc -ico app.ico -o app.syso
    goto build
)
echo  WARNING: windres/rsrc not found — icon will not be embedded.
echo           Install MinGW or: go install github.com/akavel/rsrc@latest

:build
:: Step 2 — compile
echo  [2/2] Compiling...
if not exist ..\dist mkdir ..\dist
go build -ldflags="-s -w -H windowsgui -X main.clientVersion=%VERSION%" -o ..\dist\MinecraftModUpdater.exe .

if %ERRORLEVEL% neq 0 (
    echo.
    echo  ERROR: Build failed.
    exit /b 1
)

echo.
echo  Done!  Output: dist\MinecraftModUpdater.exe  (v%VERSION%)
echo.
