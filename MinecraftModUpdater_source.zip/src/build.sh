#!/bin/bash
# Cross-compile build script for MinecraftModUpdater with custom icon
# Requires: Go with Windows cross-compile support
# For .syso generation: sudo apt install mingw-w64  OR  go install github.com/akavel/rsrc@latest

set -e

export GOARCH=amd64
export GOOS=windows
export CGO_ENABLED=0

echo "[1/3] Generating Windows resource object (app.syso)..."

if command -v x86_64-w64-mingw32-windres &>/dev/null; then
    x86_64-w64-mingw32-windres -i app.rc -O coff -o app.syso
    echo "      Used: x86_64-w64-mingw32-windres"
elif command -v rsrc &>/dev/null; then
    rsrc -ico app.ico -o app.syso
    echo "      Used: rsrc"
else
    echo "WARNING: Neither windres nor rsrc found."
    echo "         Icon will NOT appear in Task Manager."
    echo "         Install with: sudo apt install mingw-w64"
    echo "         Or:           go install github.com/akavel/rsrc@latest"
    echo ""
fi

echo "[2/3] Building exe..."
go build -ldflags="-s -w -H windowsgui" -o ../dist/MinecraftModUpdater_icon.exe .

echo "[3/3] Done! Output: dist/MinecraftModUpdater_icon.exe"
