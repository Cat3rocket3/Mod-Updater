package main

import (
	"archive/zip"
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

const (
	defaultBackend = "http://82.137.73.40:8080"
	listenAddr     = "127.0.0.1:17845"
	pollInterval   = 60
)

// clientVersion is embedded at build time via -ldflags "-X main.clientVersion=1.0.0"
var clientVersion = "1.0.0"

type Config struct {
	BackendURL        string `json:"backend_url"`
	ModsFolder        string `json:"mods_folder"`
	Listening         bool   `json:"listening"`
	LastUpdateID      string `json:"last_update_id"`
	Variant           string `json:"variant"`
	InstalledVersion  string `json:"installed_version"` // set after successful self-update
}

type Stats struct {
	StartupRegistered   bool   `json:"startup_registered"`
	Listening           bool   `json:"listening"`
	Countdown           int    `json:"countdown"`
	LastCheck           string `json:"last_check"`
	LastInstall         string `json:"last_install"`
	LastResult          string `json:"last_result"`
	LastAction          string `json:"last_action"`
	CurrentStage        string `json:"current_stage"`
	UpdateProgress      int    `json:"update_progress"`
	UpdateFound         bool   `json:"update_found"`
	FoundUpdateID       string `json:"found_update_id"`
	Busy                bool   `json:"busy"`
	TotalChecks         int    `json:"total_checks"`
	TotalInstalls       int    `json:"total_installs"`
	LastDownloadSize    int64  `json:"last_download_size"`
	ServerAvailable     bool   `json:"server_available"`
	ServerLatestID      string `json:"server_latest_update_id"`
	ServerHistory       int    `json:"server_history_count"`
	ServerLatestTime    string `json:"server_latest_created_at"`
	ServerFileCount     int    `json:"server_latest_file_count"`
	ServerPackageSize   int64  `json:"server_latest_package_size"`
	HasManagedManifest  bool   `json:"has_managed_manifest"`
	FirstManagedInstall string `json:"first_managed_install_at"`
	DownloadSpeed       int64  `json:"download_speed"`
	SelfUpdateAvailable bool   `json:"self_update_available"`
	SelfUpdateVersion   string `json:"self_update_version"`
}

type ManagedManifest struct {
	LastUpdateID          string   `json:"last_update_id"`
	FirstManagedInstallAt string   `json:"first_managed_install_at"`
	LastInstalledAt       string   `json:"last_installed_at"`
	ManagedFiles          []string `json:"managed_files"`
}

type ServerManifest struct {
	UpdateID     string   `json:"update_id"`
	CreatedAt    string   `json:"created_at"`
	ManagedFiles []string `json:"managed_files"`
}

type App struct {
	mu           sync.Mutex
	cfg          Config
	stats        Stats
	dataDir      string
	configPath   string
	logPath      string
	statePath    string
	workDir      string
	exePath      string
	client       *http.Client
	server       *http.Server
	taskCancel   context.CancelFunc // cancels the current download/install task
}

func main() {
	background := len(os.Args) > 1 && os.Args[1] == "--background"
	if isPanelRunning() {
		if !background {
			openBrowser("http://" + listenAddr)
		}
		return
	}
	app, err := NewApp()
	if err != nil {
		return
	}
	app.run(!background)
}

func NewApp() (*App, error) {
	dataDir := programDataDir()
	if err := os.MkdirAll(dataDir, 0755); err != nil {
		return nil, err
	}
	logPath := filepath.Join(dataDir, "client.log")
	logFile, _ := os.OpenFile(logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	log.SetOutput(logFile)
	log.SetFlags(log.LstdFlags | log.Lshortfile)

	exe, _ := os.Executable()
	app := &App{
		dataDir:             dataDir,
		configPath:          filepath.Join(dataDir, "config.json"),
		statePath:           filepath.Join(dataDir, "state.json"),
		workDir:             filepath.Join(dataDir, "work"),
		logPath:             logPath,
		exePath:             exe,
		client: &http.Client{
			Transport: &http.Transport{
				DialContext: (&net.Dialer{
					Timeout:   30 * time.Second,
					KeepAlive: 30 * time.Second,
				}).DialContext,
				TLSHandshakeTimeout:   15 * time.Second,
				ResponseHeaderTimeout: 30 * time.Second,
				ExpectContinueTimeout: 5 * time.Second,
				DisableCompression:    true,          // skip gzip overhead on binary files
				ForceAttemptHTTP2:     false,         // HTTP/1.1 better for large single-file downloads
				ReadBufferSize:        256 * 1024,    // 256KB TCP read buffer
				WriteBufferSize:       64 * 1024,
				MaxIdleConns:          10,
				IdleConnTimeout:       90 * time.Second,
			},
		},
	}
	app.cfg = Config{
		BackendURL: defaultBackend,
		Listening:  true,
	}
	app.stats = Stats{
		Listening:      true,
		Countdown:      pollInterval,
		CurrentStage:   "Idle",
		UpdateProgress: 0,
	}
	app.load()
	app.stats.Listening = app.cfg.Listening
	app.stats.StartupRegistered = app.isStartupRegistered()
	mm, _ := app.loadManagedManifest()
	app.stats.HasManagedManifest = mm != nil
	if mm != nil {
		app.stats.FirstManagedInstall = mm.FirstManagedInstallAt
	}
	_ = os.MkdirAll(app.workDir, 0755)
	globalApp = app
	return app, nil
}

func programDataDir() string {
	if runtime.GOOS == "windows" {
		if pd := os.Getenv("ProgramData"); pd != "" {
			return filepath.Join(pd, "MinecraftModUpdater")
		}
	}
	cwd, _ := os.Getwd()
	return filepath.Join(cwd, "MinecraftModUpdaterData")
}

func (a *App) load() {
	if b, err := os.ReadFile(a.configPath); err == nil {
		_ = json.Unmarshal(b, &a.cfg)
	}
	if b, err := os.ReadFile(a.statePath); err == nil {
		_ = json.Unmarshal(b, &a.stats)
	}
	if strings.TrimSpace(a.cfg.BackendURL) == "" {
		a.cfg.BackendURL = defaultBackend
	}
	if strings.TrimSpace(a.cfg.Variant) == "" {
		a.cfg.Variant = "default"
	}
	if a.stats.Countdown <= 0 || a.stats.Countdown > pollInterval {
		a.stats.Countdown = pollInterval
	}
	// Always reset transient runtime state on startup.
	// If the process was killed mid-download these would be stale forever.
	a.stats.Busy = false
	a.stats.CurrentStage = "Idle"
	a.stats.UpdateProgress = 0
}

func (a *App) save() {
	_ = os.WriteFile(a.configPath, mustJSON(a.cfg), 0644)
	_ = os.WriteFile(a.statePath, mustJSON(a.stats), 0644)
}

func mustJSON(v any) []byte {
	b, _ := json.MarshalIndent(v, "", "  ")
	return b
}

func (a *App) run(openUI bool) {
	mode := "background"
	if openUI {
		mode = "ui"
	}
	log.Println(mode, "mode start")
	_ = a.ensureStartup()

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	go a.pollLoop(ctx)
	go a.selfUpdateLoop(ctx)

	mux := http.NewServeMux()
	mux.HandleFunc("/", a.handleIndex)
	mux.HandleFunc("/api/ui/status", a.handleStatus)
	mux.HandleFunc("/api/ui/save", a.handleSave)
	mux.HandleFunc("/api/ui/check", a.handleCheck)
	mux.HandleFunc("/api/ui/repull", a.handleRepull)
	mux.HandleFunc("/api/ui/listen/start", a.handleListenStart)
	mux.HandleFunc("/api/ui/listen/stop", a.handleListenStop)
	mux.HandleFunc("/api/ui/select-folder", a.handleSelectFolder)
	mux.HandleFunc("/api/ui/open-logs", a.handleOpenLogs)
	mux.HandleFunc("/api/ui/register-startup", a.handleRegisterStartup)
	mux.HandleFunc("/api/ui/bootstrap/clean", a.handleBootstrapClean)
	mux.HandleFunc("/api/ui/bootstrap/keep", a.handleBootstrapKeep)
	mux.HandleFunc("/api/ui/open", a.handleOpenPanel)
	mux.HandleFunc("/api/ui/cancel", a.handleCancel)
	mux.HandleFunc("/api/ui/patch-notes", a.handlePatchNotes)
	mux.HandleFunc("/api/ui/variants", a.handleVariants)
	mux.HandleFunc("/api/ui/set-variant", a.handleSetVariant)
	mux.HandleFunc("/api/ui/self-update", a.handleSelfUpdate)
	mux.HandleFunc("/api/ui/check-app-update", a.handleCheckAppUpdate)
	mux.HandleFunc("/api/ui/quit", a.handleQuit)
	a.server = &http.Server{Addr: listenAddr, Handler: mux}

	if runtime.GOOS == "windows" {
		go runTray()
	}
	if openUI {
		go func() {
			time.Sleep(900 * time.Millisecond)
			openBrowser("http://" + listenAddr)
		}()
	}

	go func() {
		<-ctx.Done()
		if a.server != nil {
			_ = a.server.Shutdown(context.Background())
		}
	}()
	if err := a.server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Println("ui server error:", err)
	}
	log.Println(mode, "mode stop")
}

func isPanelRunning() bool {
	client := &http.Client{Timeout: 800 * time.Millisecond}
	resp, err := client.Get("http://" + listenAddr + "/api/ui/status")
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	return resp.StatusCode == 200
}

func (a *App) pollLoop(ctx context.Context) {
	t := time.NewTicker(1 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			trigger := false
			a.mu.Lock()
			if a.cfg.Listening && !a.stats.Busy {
				a.stats.Listening = true
				a.stats.Countdown--
				if a.stats.Countdown <= 0 {
					a.stats.Countdown = pollInterval
					trigger = true
					a.save() // only save on countdown reset
				}
			} else {
				a.stats.Listening = a.cfg.Listening
			}
			a.mu.Unlock()

			if trigger {
				go a.performCheckAndMaybePull("Auto pull", false)
			}
		}
	}
}

func (a *App) beginBusy(reason string) bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.stats.Busy {
		return false
	}
	a.stats.Busy = true
	a.stats.LastAction = reason
	a.stats.TotalChecks++
	a.stats.LastCheck = time.Now().Format(time.RFC3339)
	a.stats.CurrentStage = "Checking server"
	a.stats.UpdateProgress = 5
	a.stats.UpdateFound = false
	a.stats.FoundUpdateID = ""
	a.save()
	return true
}

func (a *App) endBusy(finalMessage string) {
	a.mu.Lock()
	a.stats.Busy = false
	a.stats.LastResult = finalMessage
	if finalMessage == "Already on latest update" || strings.HasPrefix(finalMessage, "No update available") {
		a.stats.CurrentStage = "Idle"
		a.stats.UpdateProgress = 0
	} else if strings.HasPrefix(finalMessage, "Update installed") || strings.HasPrefix(finalMessage, "Repull installed") {
		a.stats.CurrentStage = "Completed"
		a.stats.UpdateProgress = 100
	} else if strings.Contains(strings.ToLower(finalMessage), "failed") {
		a.stats.CurrentStage = "Failed"
	}
	a.save()
	a.mu.Unlock()
	log.Println(finalMessage)
}

func (a *App) updateStage(stage string, progress int) {
	a.mu.Lock()
	a.stats.CurrentStage = stage
	a.stats.UpdateProgress = progress
	a.mu.Unlock()
}

func (a *App) performCheckAndMaybePull(reason string, force bool) {
	if !a.beginBusy(reason) {
		a.setResult("Another update task is already running")
		return
	}

	// Create a cancellable context for this task so the user can abort mid-download
	ctx, cancel := context.WithCancel(context.Background())
	a.mu.Lock()
	a.taskCancel = cancel
	a.mu.Unlock()

	finished := false
	defer func() {
		cancel()
		a.mu.Lock()
		a.taskCancel = nil
		a.mu.Unlock()
		if !finished {
			a.endBusy("Cancelled")
		}
	}()

	a.mu.Lock()
	backend := strings.TrimRight(a.cfg.BackendURL, "/")
	modsFolder := strings.TrimSpace(a.cfg.ModsFolder)
	localID := a.cfg.LastUpdateID
	variant := a.cfg.Variant
	if variant == "" {
		variant = "default"
	}
	a.mu.Unlock()

	if backend == "" {
		finished = true
		a.endBusy("Check failed: backend URL is empty")
		return
	}
	if modsFolder == "" {
		finished = true
		a.endBusy("Check failed: mods folder is not set")
		return
	}

	statusURL := backend + "/api/status?variant=" + variant
	req, _ := http.NewRequestWithContext(ctx, "GET", statusURL, nil)
	resp, err := a.client.Do(req)
	if err != nil {
		finished = true
		if ctx.Err() != nil {
			a.endBusy("Cancelled")
		} else {
			a.endBusy("Check failed: " + err.Error())
		}
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		finished = true
		a.endBusy(fmt.Sprintf("Check failed: status endpoint returned %d", resp.StatusCode))
		return
	}

	var server map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&server); err != nil {
		finished = true
		a.endBusy("Check failed: invalid backend JSON")
		return
	}

	serverAvailable := asBool(server["available_update"])
	serverLatestID := asString(server["latest_update_id"])
	serverHistory := asInt(server["history_count"])
	serverLatestTime := asString(server["latest_created_at"])
	serverFileCount := asInt(server["latest_file_count"])
	serverPackageSize := asInt64(server["latest_package_size"])

	a.mu.Lock()
	a.stats.ServerAvailable = serverAvailable
	a.stats.ServerLatestID = serverLatestID
	a.stats.ServerHistory = serverHistory
	a.stats.ServerLatestTime = serverLatestTime
	a.stats.ServerFileCount = serverFileCount
	a.stats.ServerPackageSize = serverPackageSize
	a.mu.Unlock()

	if !serverAvailable {
		finished = true
		a.endBusy("No update available on server")
		return
	}
	if serverLatestID == "" {
		finished = true
		a.endBusy("Check failed: backend returned empty latest_update_id")
		return
	}

	serverManifest, err := fetchServerManifest(a.client, ctx, backend, variant)
	if err != nil {
		finished = true
		if ctx.Err() != nil {
			a.endBusy("Cancelled")
		} else {
			a.endBusy("Check failed: " + err.Error())
		}
		return
	}
	newManaged := serverManifest.ManagedFiles
	oldManifest, err := a.loadManagedManifest()
	if err != nil {
		finished = true
		a.endBusy("Check failed: cannot load local managed manifest")
		return
	}

	a.mu.Lock()
	a.stats.UpdateFound = true
	a.stats.FoundUpdateID = serverLatestID
	a.stats.HasManagedManifest = oldManifest != nil
	if oldManifest != nil {
		a.stats.FirstManagedInstall = oldManifest.FirstManagedInstallAt
	}
	a.mu.Unlock()

	if !force && localID == serverLatestID && oldManifest != nil {
		finished = true
		a.endBusy("Already on latest update")
		return
	}

	isBootstrap := oldManifest == nil

	a.updateStage("Clearing work folder", 12)
	if err := clearFolderContents(a.workDir); err != nil {
		finished = true
		a.endBusy("Install failed: cannot clear work folder: " + err.Error())
		return
	}

	zipPath := filepath.Join(a.workDir, "latest.zip")
	// Show resume info if a partial file already exists from a previous attempt
	if fi, err := os.Stat(zipPath); err == nil && fi.Size() > 0 {
		a.updateStage(fmt.Sprintf("Resuming download from %s", humanBytes(fi.Size())), 20)
	} else {
		a.updateStage("Downloading update", 20)
	}
	size, err := a.downloadWithRetry(ctx, backend+"/download/latest?variant="+variant, zipPath, func(downloaded, total int64, speed int64) {
		progress := 20
		if total > 0 {
			pct := int((downloaded * 100) / total)
			if pct < 0 {
				pct = 0
			}
			if pct > 100 {
				pct = 100
			}
			progress = 20 + int(float64(pct)*0.45)
		} else if downloaded > 0 {
			progress = 45
		}
		a.mu.Lock()
		a.stats.CurrentStage = fmt.Sprintf("Downloading update (%s)", humanBytes(downloaded))
		a.stats.UpdateProgress = progress
		a.stats.DownloadSpeed = speed
		a.mu.Unlock()
	})
	// Clear speed once download is done
	a.mu.Lock()
	a.stats.DownloadSpeed = 0
	a.mu.Unlock()
	if err != nil {
		finished = true
		if ctx.Err() != nil {
			a.endBusy("Cancelled")
		} else {
			a.endBusy("Download failed: " + err.Error())
		}
		return
	}
	data, err := os.ReadFile(zipPath)
	if err != nil {
		finished = true
		a.endBusy("Download failed: cannot read saved package")
		return
	}
	if err := os.MkdirAll(modsFolder, 0755); err != nil {
		finished = true
		a.endBusy("Install failed: cannot create mods folder")
		return
	}

	if isBootstrap {
		a.updateStage("Preparing first managed install", 52)
		if err := deleteManagedDifference(modsFolder, newManaged, []string{}); err != nil {
			finished = true
			a.endBusy("Install failed: cannot clear incoming managed files: " + err.Error())
			return
		}
	} else if force {
		a.updateStage("Removing currently managed mods", 52)
		if err := deleteManagedDifference(modsFolder, oldManifest.ManagedFiles, []string{}); err != nil {
			finished = true
			a.endBusy("Install failed: cannot clear managed mods: " + err.Error())
			return
		}
	} else {
		a.updateStage("Removing outdated managed mods", 52)
		if err := deleteManagedDifference(modsFolder, oldManifest.ManagedFiles, newManaged); err != nil {
			finished = true
			a.endBusy("Install failed: cannot remove old managed mods: " + err.Error())
			return
		}
	}

	a.updateStage("Installing managed update", 78)
	if err := installZipManaged(data, modsFolder, newManaged, func(done, total int, stage string) {
		progress := 78
		if total > 0 {
			progress = 78 + int(float64(done)/float64(total)*20.0)
			if progress > 98 {
				progress = 98
			}
		}
		a.updateStage(stage, progress)
	}); err != nil {
		finished = true
		a.endBusy("Install failed: " + err.Error())
		return
	}

	installTime := time.Now().Format(time.RFC3339)
	newLocalManifest := ManagedManifest{LastUpdateID: serverLatestID, LastInstalledAt: installTime, ManagedFiles: newManaged}
	if oldManifest != nil {
		newLocalManifest.FirstManagedInstallAt = oldManifest.FirstManagedInstallAt
	} else {
		newLocalManifest.FirstManagedInstallAt = installTime
	}
	if err := a.saveManagedManifest(newLocalManifest); err != nil {
		finished = true
		a.endBusy("Install failed: cannot save managed manifest")
		return
	}

	a.mu.Lock()
	a.cfg.LastUpdateID = serverLatestID
	a.stats.LastInstall = installTime
	a.stats.TotalInstalls++
	a.stats.LastDownloadSize = size
	a.stats.UpdateProgress = 100
	a.stats.CurrentStage = "Completed"
	a.stats.HasManagedManifest = true
	a.stats.FirstManagedInstall = newLocalManifest.FirstManagedInstallAt
	a.save()
	a.mu.Unlock()

	finished = true
	if force {
		a.endBusy("Repull installed: " + serverLatestID)
	} else if isBootstrap {
		a.endBusy("First managed install complete: " + serverLatestID)
	} else {
		a.endBusy("Update installed: " + serverLatestID)
	}
}

func normalizeManagedPath(p string) string {
	p = strings.ReplaceAll(p, "\\", "/")
	p = path.Clean(strings.TrimSpace(p))
	p = strings.TrimPrefix(p, "/")
	if p == "." {
		return ""
	}
	return p
}

func (a *App) currentManagedManifestPath() string {
	modsFolder := strings.TrimSpace(a.cfg.ModsFolder)
	return managedManifestPathForFolder(modsFolder)
}

func managedManifestPathForFolder(modsFolder string) string {
	modsFolder = strings.TrimSpace(modsFolder)
	if modsFolder == "" {
		return ""
	}
	return filepath.Join(modsFolder, ".minecraft_mod_updater_manifest.json")
}

func (a *App) loadManagedManifest() (*ManagedManifest, error) {
	manifestPath := a.currentManagedManifestPath()
	if manifestPath == "" {
		return nil, nil
	}
	b, err := os.ReadFile(manifestPath)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var mm ManagedManifest
	if err := json.Unmarshal(b, &mm); err != nil {
		return nil, err
	}
	if mm.ManagedFiles == nil {
		mm.ManagedFiles = []string{}
	}
	return &mm, nil
}

func (a *App) saveManagedManifest(mm ManagedManifest) error {
	manifestPath := a.currentManagedManifestPath()
	if manifestPath == "" {
		return fmt.Errorf("mods folder is not set")
	}
	if mm.FirstManagedInstallAt == "" {
		mm.FirstManagedInstallAt = time.Now().Format(time.RFC3339)
	}
	if mm.LastInstalledAt == "" {
		mm.LastInstalledAt = time.Now().Format(time.RFC3339)
	}
	seen := map[string]bool{}
	cleaned := make([]string, 0, len(mm.ManagedFiles))
	for _, f := range mm.ManagedFiles {
		n := normalizeManagedPath(f)
		if n == "" || seen[n] {
			continue
		}
		seen[n] = true
		cleaned = append(cleaned, n)
	}
	mm.ManagedFiles = cleaned
	if err := os.MkdirAll(filepath.Dir(manifestPath), 0755); err != nil {
		return err
	}
	if err := os.WriteFile(manifestPath, mustJSON(mm), 0644); err != nil {
		return err
	}
	return nil
}

func deleteManagedDifference(modsFolder string, oldFiles, newFiles []string) error {
	newSet := map[string]bool{}
	for _, f := range newFiles {
		n := normalizeManagedPath(f)
		if n != "" {
			newSet[n] = true
		}
	}
	for _, f := range oldFiles {
		n := normalizeManagedPath(f)
		if n == "" || newSet[n] {
			continue
		}
		target := filepath.Join(modsFolder, filepath.FromSlash(n))
		if err := os.RemoveAll(target); err != nil && !os.IsNotExist(err) {
			return err
		}
		removeEmptyParents(filepath.Dir(target), modsFolder)
	}
	return nil
}

func removeEmptyParents(dir, stop string) {
	stop = filepath.Clean(stop)
	for {
		dir = filepath.Clean(dir)
		if dir == stop || len(dir) < len(stop) {
			return
		}
		entries, err := os.ReadDir(dir)
		if err != nil || len(entries) > 0 {
			return
		}
		if err := os.Remove(dir); err != nil {
			return
		}
		dir = filepath.Dir(dir)
	}
}

func fetchServerManifest(client *http.Client, ctx context.Context, backend string, variant string) (*ServerManifest, error) {
	url := strings.TrimRight(backend, "/") + "/api/manifest/latest?variant=" + variant
	req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("manifest endpoint returned %d", resp.StatusCode)
	}
	var sm ServerManifest
	if err := json.NewDecoder(resp.Body).Decode(&sm); err != nil {
		return nil, fmt.Errorf("invalid manifest JSON")
	}
	return &sm, nil
}

func installZipManaged(data []byte, modsFolder string, allowed []string, progress func(done, total int, stage string)) error {
	allowSet := map[string]bool{}
	for _, f := range allowed {
		n := normalizeManagedPath(f)
		if n != "" {
			allowSet[n] = true
		}
	}
	reader, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return err
	}
	totalAllowed := 0
	for _, f := range reader.File {
		clean := normalizeManagedPath(strings.ReplaceAll(f.Name, "\\", "/"))
		if clean == "" {
			continue
		}
		base := filepath.Base(clean)
		if strings.HasPrefix(base, "manifest_") && strings.HasSuffix(strings.ToLower(base), ".json") {
			continue
		}
		if allowSet[clean] && !f.FileInfo().IsDir() {
			totalAllowed++
		}
	}
	doneCount := 0
	for _, f := range reader.File {
		clean := normalizeManagedPath(strings.ReplaceAll(f.Name, "\\", "/"))
		if clean == "" {
			continue
		}
		base := filepath.Base(clean)
		if strings.HasPrefix(base, "manifest_") && strings.HasSuffix(strings.ToLower(base), ".json") {
			continue
		}
		if !allowSet[clean] {
			continue
		}
		target := filepath.Join(modsFolder, filepath.FromSlash(clean))
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
			return err
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.Create(target)
		if err != nil {
			rc.Close()
			return err
		}
		_, cErr := io.Copy(out, rc)
		rc.Close()
		closeErr := out.Close()
		if cErr != nil {
			return cErr
		}
		if closeErr != nil {
			return closeErr
		}
		doneCount++
		if progress != nil {
			progress(doneCount, totalAllowed, "Installing managed update")
		}
	}
	if progress != nil {
		progress(totalAllowed, totalAllowed, "Installing managed update")
	}
	return nil
}

const (
	downloadMaxRetries = 5
	downloadBaseDelay  = 2 * time.Second
	downloadMaxDelay   = 60 * time.Second
)

// downloadWithRetry wraps downloadWithProgress with exponential backoff and
// HTTP Range resume. On each attempt it checks how much of the partial file
// already exists and passes that offset so the download resumes mid-file.
// The partial file is preserved across attempts and across restarts so even a
// manually cancelled download can be resumed next time.
func (a *App) downloadWithRetry(ctx context.Context, url string, outPath string, report func(downloaded, total int64, speed int64)) (int64, error) {
	var lastErr error
	for attempt := 0; attempt <= downloadMaxRetries; attempt++ {
		if ctx.Err() != nil {
			// User cancelled — leave the partial file on disk so the next
			// run can resume. Do NOT treat this as an error worth reporting.
			return 0, ctx.Err()
		}

		if attempt > 0 {
			delay := downloadBaseDelay * (1 << (attempt - 1))
			if delay > downloadMaxDelay {
				delay = downloadMaxDelay
			}
			a.mu.Lock()
			a.stats.CurrentStage = fmt.Sprintf("Retrying download (attempt %d/%d, waiting %s)", attempt, downloadMaxRetries, delay.Round(time.Second))
			a.stats.UpdateProgress = 20
			a.stats.DownloadSpeed = 0
			a.mu.Unlock()
			log.Printf("download attempt %d failed: %v — retrying in %s", attempt, lastErr, delay)

			select {
			case <-ctx.Done():
				return 0, ctx.Err()
			case <-time.After(delay):
			}
		}

		// Check how much we already have on disk from a previous (partial) attempt
		var resumeOffset int64
		if fi, err := os.Stat(outPath); err == nil && fi.Size() > 0 {
			resumeOffset = fi.Size()
		}

		size, err := downloadWithProgress(a.client, ctx, url, outPath, resumeOffset, report)
		if err == nil {
			return size, nil
		}

		// User cancelled — keep partial file, stop retrying
		if ctx.Err() != nil {
			return 0, ctx.Err()
		}

		// 4xx = permanent client error (wrong URL, auth), no point retrying
		if strings.Contains(err.Error(), "endpoint returned 4") {
			return 0, err
		}

		// Server doesn't support Range — delete partial file so next attempt starts fresh
		if strings.Contains(err.Error(), "range not supported") {
			_ = os.Remove(outPath)
			resumeOffset = 0
		}

		lastErr = err
	}
	return 0, fmt.Errorf("download failed after %d attempts: %w", downloadMaxRetries+1, lastErr)
}

func downloadWithProgress(client *http.Client, ctx context.Context, url string, outPath string, resumeOffset int64, report func(downloaded, total int64, speed int64)) (int64, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Accept-Encoding", "identity")

	// Request only the bytes we don't have yet
	if resumeOffset > 0 {
		req.Header.Set("Range", fmt.Sprintf("bytes=%d-", resumeOffset))
	}

	resp, err := client.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()

	switch resp.StatusCode {
	case 200:
		// Server ignored our Range header and sent the full file — start fresh
		if resumeOffset > 0 {
			if err := os.Remove(outPath); err != nil && !os.IsNotExist(err) {
				return 0, err
			}
			resumeOffset = 0
		}
	case 206:
		// Server honours partial content — we can append
	case 416:
		// Range not satisfiable — our offset is past EOF, file is already complete
		fi, err := os.Stat(outPath)
		if err != nil {
			return 0, fmt.Errorf("range not supported: %w", err)
		}
		return fi.Size(), nil
	default:
		if resp.StatusCode/100 == 4 {
			return 0, fmt.Errorf("endpoint returned %d", resp.StatusCode)
		}
		return 0, fmt.Errorf("endpoint returned %d", resp.StatusCode)
	}

	// Open the file: append if resuming, create fresh otherwise
	var out *os.File
	if resumeOffset > 0 && resp.StatusCode == 206 {
		out, err = os.OpenFile(outPath, os.O_WRONLY|os.O_APPEND, 0644)
	} else {
		out, err = os.Create(outPath)
	}
	if err != nil {
		return 0, err
	}
	defer out.Close()

	bufWriter := bufio.NewWriterSize(out, 4*1024*1024)
	defer bufWriter.Flush()

	// Total size = what server reports as full content length
	total := resp.ContentLength
	if resp.StatusCode == 206 {
		// Content-Range: bytes START-END/TOTAL — extract TOTAL
		if cr := resp.Header.Get("Content-Range"); cr != "" {
			var start, end, fullTotal int64
			if n, _ := fmt.Sscanf(cr, "bytes %d-%d/%d", &start, &end, &fullTotal); n == 3 {
				total = fullTotal
			}
		}
	}

	// downloaded tracks bytes written this session; add resumeOffset for UI progress
	var downloaded int64
	lastReport := time.Now()
	lastProgress := time.Now() // tracks when we last received bytes — for stall detection
	var lastBytes int64
	buf := make([]byte, 2*1024*1024)

	for {
		if ctx.Err() != nil {
			_ = bufWriter.Flush()
			return resumeOffset + downloaded, ctx.Err()
		}

		// Stall detection: if no bytes received for 45 seconds, treat as error so retry kicks in
		if time.Since(lastProgress) > 45*time.Second && downloaded == 0 && resumeOffset == 0 {
			return 0, fmt.Errorf("download stalled: no data received for 45s")
		}

		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			lastProgress = time.Now() // reset stall timer on any data
			wn, werr := bufWriter.Write(buf[:n])
			if werr != nil {
				return resumeOffset + downloaded, werr
			}
			downloaded += int64(wn)

			now := time.Now()
			if elapsed := now.Sub(lastReport).Seconds(); elapsed >= 1.0 {
				speed := int64(float64(downloaded-lastBytes) / elapsed)
				lastBytes = downloaded
				lastReport = now
				if report != nil {
					report(resumeOffset+downloaded, total, speed)
				}
			}
		} else if downloaded > 0 && time.Since(lastProgress) > 45*time.Second {
			// Was receiving data but stopped — stall after partial download
			return resumeOffset + downloaded, fmt.Errorf("download stalled mid-transfer")
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			return resumeOffset + downloaded, rerr
		}
	}

	if err := bufWriter.Flush(); err != nil {
		return resumeOffset + downloaded, err
	}
	if report != nil {
		report(resumeOffset+downloaded, total, 0)
	}
	return resumeOffset + downloaded, nil
}

func humanBytes(n int64) string {
	if n < 1024 {
		return fmt.Sprintf("%d B", n)
	}
	if n < 1024*1024 {
		return fmt.Sprintf("%.1f KB", float64(n)/1024)
	}
	if n < 1024*1024*1024 {
		return fmt.Sprintf("%.2f MB", float64(n)/(1024*1024))
	}
	return fmt.Sprintf("%.2f GB", float64(n)/(1024*1024*1024))
}

func clearFolderContents(dir string) error {
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return os.MkdirAll(dir, 0755)
		}
		return err
	}
	for _, entry := range entries {
		if err := os.RemoveAll(filepath.Join(dir, entry.Name())); err != nil {
			return err
		}
	}
	return nil
}

func installZipToFolder(data []byte, modsFolder string) error {
	reader, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return err
	}
	for _, f := range reader.File {
		clean := filepath.Clean(strings.ReplaceAll(f.Name, "\\", "/"))
		clean = strings.TrimPrefix(clean, "/")
		clean = strings.TrimPrefix(clean, "./")
		if clean == "" || clean == "." {
			continue
		}
		if strings.Contains(clean, "..") {
			continue
		}
		target := filepath.Join(modsFolder, filepath.FromSlash(clean))
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0755); err != nil {
			return err
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.Create(target)
		if err != nil {
			rc.Close()
			return err
		}
		_, cErr := io.Copy(out, rc)
		rc.Close()
		closeErr := out.Close()
		if cErr != nil {
			return cErr
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func (a *App) setResult(msg string) {
	a.mu.Lock()
	a.stats.LastResult = msg
	a.save()
	a.mu.Unlock()
	log.Println(msg)
}

func asString(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case nil:
		return ""
	default:
		return fmt.Sprint(v)
	}
}
func asBool(v any) bool {
	b, ok := v.(bool)
	return ok && b
}
func asInt(v any) int {
	switch t := v.(type) {
	case float64:
		return int(t)
	case int:
		return t
	default:
		return 0
	}
}
func asInt64(v any) int64 {
	switch t := v.(type) {
	case float64:
		return int64(t)
	case int64:
		return t
	case int:
		return int64(t)
	default:
		return 0
	}
}

func (a *App) handleIndex(w http.ResponseWriter, r *http.Request) {
	t := template.Must(template.New("index").Parse(pageHTML))
	_ = t.Execute(w, nil)
}

func (a *App) handleStatus(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	defer a.mu.Unlock()
	resp := map[string]any{
		"config": map[string]any{
			"backend_url":    a.cfg.BackendURL,
			"mods_folder":    a.cfg.ModsFolder,
			"last_update_id": a.cfg.LastUpdateID,
			"listening":      a.cfg.Listening,
			"variant":        a.cfg.Variant,
		},
		"stats":                 a.stats,
		"poll_interval":         pollInterval,
		"log_path":              a.logPath,
		"work_dir":              a.workDir,
		"managed_manifest_path": a.currentManagedManifestPath(),
		"client_version": func() string {
				if a.cfg.InstalledVersion != "" {
					return a.cfg.InstalledVersion
				}
				return clientVersion
			}(),
	}
	writeJSON(w, resp)
}

func (a *App) handleSave(w http.ResponseWriter, r *http.Request) {
	var req struct {
		BackendURL string `json:"backend_url"`
		ModsFolder string `json:"mods_folder"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeJSON(w, map[string]any{"ok": false, "message": "Invalid request"})
		return
	}
	a.mu.Lock()
	a.cfg.BackendURL = strings.TrimSpace(req.BackendURL)
	a.cfg.ModsFolder = strings.TrimSpace(req.ModsFolder)
	if a.cfg.BackendURL == "" {
		a.cfg.BackendURL = defaultBackend
	}
	a.save()
	a.mu.Unlock()
	writeJSON(w, map[string]any{"ok": true, "message": "Settings saved"})
}

func (a *App) handleVariants(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	backend := strings.TrimRight(a.cfg.BackendURL, "/")
	a.mu.Unlock()
	req, _ := http.NewRequestWithContext(r.Context(), "GET", backend+"/api/variants", nil)
	resp, err := a.client.Do(req)
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "variants": []any{}, "message": err.Error()})
		return
	}
	defer resp.Body.Close()
	var variants []map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&variants); err != nil {
		writeJSON(w, map[string]any{"ok": false, "variants": []any{}, "message": "invalid response"})
		return
	}
	writeJSON(w, map[string]any{"ok": true, "variants": variants})
}

func (a *App) handleSetVariant(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Variant string `json:"variant"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || strings.TrimSpace(req.Variant) == "" {
		writeJSON(w, map[string]any{"ok": false, "message": "Invalid variant"})
		return
	}
	a.mu.Lock()
	a.cfg.Variant = strings.TrimSpace(req.Variant)
	a.cfg.LastUpdateID = "" // reset so it re-checks against new variant
	a.save()
	a.mu.Unlock()
	writeJSON(w, map[string]any{"ok": true, "message": "Variant set to " + req.Variant})
}

func (a *App) handleCheck(w http.ResponseWriter, r *http.Request) {
	go a.performCheckAndMaybePull("Manual check", false)
	writeJSON(w, map[string]any{"ok": true, "message": "Check started"})
}

func (a *App) handleRepull(w http.ResponseWriter, r *http.Request) {
	go a.performCheckAndMaybePull("Repull latest", true)
	writeJSON(w, map[string]any{"ok": true, "message": "Repull started"})
}

func (a *App) handleListenStart(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	a.cfg.Listening = true
	a.stats.Listening = true
	a.stats.Countdown = pollInterval
	a.save()
	a.mu.Unlock()
	writeJSON(w, map[string]any{"ok": true, "message": "Listening started"})
}

func (a *App) handleListenStop(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	a.cfg.Listening = false
	a.stats.Listening = false
	a.save()
	a.mu.Unlock()
	writeJSON(w, map[string]any{"ok": true, "message": "Listening stopped"})
}

func (a *App) handleSelectFolder(w http.ResponseWriter, r *http.Request) {
	path, err := selectFolder()
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "message": err.Error()})
		return
	}
	if path == "" {
		writeJSON(w, map[string]any{"ok": false, "message": "No folder selected"})
		return
	}
	a.mu.Lock()
	a.cfg.ModsFolder = path
	a.save()
	a.mu.Unlock()
	writeJSON(w, map[string]any{"ok": true, "message": "Folder selected", "path": path})
}

func (a *App) handleOpenLogs(w http.ResponseWriter, r *http.Request) {
	openPath(a.logPath)
	writeJSON(w, map[string]any{"ok": true, "message": "Opening log file"})
}

func (a *App) handleRegisterStartup(w http.ResponseWriter, r *http.Request) {
	err := a.ensureStartup()
	a.mu.Lock()
	a.stats.StartupRegistered = a.isStartupRegistered()
	a.save()
	a.mu.Unlock()
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "message": err.Error()})
		return
	}
	writeJSON(w, map[string]any{"ok": true, "message": "Startup registration updated"})
}

func (a *App) handleBootstrapClean(w http.ResponseWriter, r *http.Request) {
	go a.performCheckAndMaybePull("Bootstrap install", false)
	writeJSON(w, map[string]any{"ok": true, "message": "First managed install started"})
}

func (a *App) handleBootstrapKeep(w http.ResponseWriter, r *http.Request) {
	go a.performCheckAndMaybePull("Bootstrap install", false)
	writeJSON(w, map[string]any{"ok": true, "message": "First managed install started"})
}

func (a *App) handleOpenPanel(w http.ResponseWriter, r *http.Request) {
	openBrowser("http://" + listenAddr)
	writeJSON(w, map[string]any{"ok": true, "message": "Opening panel"})
}

func (a *App) handleQuit(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, map[string]any{"ok": true, "message": "Closing app"})
	go quitApp(a)
}

func (a *App) handleCancel(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	cancel := a.taskCancel
	a.mu.Unlock()
	if cancel != nil {
		cancel()
		writeJSON(w, map[string]any{"ok": true, "message": "Task cancelled"})
	} else {
		writeJSON(w, map[string]any{"ok": false, "message": "No task running"})
	}
}

type PatchEntry struct {
	File   string `json:"file"`
	Status string `json:"status"` // "added" or "removed"
}

func (a *App) handlePatchNotes(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	backend := strings.TrimRight(a.cfg.BackendURL, "/")
	variant := a.cfg.Variant
	if variant == "" {
		variant = "default"
	}
	a.mu.Unlock()

	if backend == "" {
		writeJSON(w, map[string]any{"ok": false, "message": "Backend URL not set"})
		return
	}

	// Fetch full history from backend — newest first
	req, _ := http.NewRequestWithContext(r.Context(), "GET", backend+"/api/history?variant="+variant, nil)
	histResp, err := a.client.Do(req)
	if err != nil {
		writeJSON(w, map[string]any{"ok": false, "message": "Could not reach backend: " + err.Error()})
		return
	}
	defer histResp.Body.Close()
	if histResp.StatusCode != 200 {
		writeJSON(w, map[string]any{"ok": false, "message": fmt.Sprintf("Backend returned %d", histResp.StatusCode)})
		return
	}

	var history []map[string]any
	if err := json.NewDecoder(histResp.Body).Decode(&history); err != nil {
		writeJSON(w, map[string]any{"ok": false, "message": "Invalid history JSON"})
		return
	}

	if len(history) == 0 {
		writeJSON(w, map[string]any{"ok": true, "entries": []any{}, "message": "No updates on server yet"})
		return
	}

	// Current = latest (index 0), Previous = one before it (index 1)
	current := history[0]
	currentID := asString(current["update_id"])
	currentTime := asString(current["created_at"])

	currentFiles := toStringSlice(current["managed_files"])
	currentSet := map[string]bool{}
	for _, f := range currentFiles {
		if n := normalizeManagedPath(f); n != "" {
			currentSet[n] = true
		}
	}

	prevSet := map[string]bool{}
	prevID := ""
	prevTime := ""
	if len(history) > 1 {
		prev := history[1]
		prevID = asString(prev["update_id"])
		prevTime = asString(prev["created_at"])
		for _, f := range toStringSlice(prev["managed_files"]) {
			if n := normalizeManagedPath(f); n != "" {
				prevSet[n] = true
			}
		}
	}

	var entries []PatchEntry
	// Added in current but not in previous
	for f := range currentSet {
		if !prevSet[f] {
			entries = append(entries, PatchEntry{File: f, Status: "added"})
		}
	}
	// Removed: in previous but not in current
	for f := range prevSet {
		if !currentSet[f] {
			entries = append(entries, PatchEntry{File: f, Status: "removed"})
		}
	}

	writeJSON(w, map[string]any{
		"ok":           true,
		"entries":      entries,
		"current_id":   currentID,
		"current_time": currentTime,
		"prev_id":      prevID,
		"prev_time":    prevTime,
		"is_first":     len(history) == 1,
		"total_updates": len(history),
	})
}

func toStringSlice(v any) []string {
	arr, ok := v.([]any)
	if !ok {
		return nil
	}
	out := make([]string, 0, len(arr))
	for _, item := range arr {
		if s, ok := item.(string); ok {
			out = append(out, s)
		}
	}
	return out
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}

func hiddenCmd(name string, args ...string) *exec.Cmd {
	cmd := exec.Command(name, args...)
	if runtime.GOOS == "windows" {
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	}
	return cmd
}

func (a *App) ensureStartup() error {
	if runtime.GOOS != "windows" {
		return nil
	}
	value := fmt.Sprintf(`"%s" --background`, a.exePath)
	cmd := hiddenCmd("reg", "add", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "MinecraftModUpdater", "/t", "REG_SZ", "/d", value, "/f")
	out, err := cmd.CombinedOutput()
	if err != nil {
		log.Println("startup registration failed:", string(out), err)
		return fmt.Errorf("startup registration failed")
	}
	a.mu.Lock()
	a.stats.StartupRegistered = true
	a.save()
	a.mu.Unlock()
	return nil
}

func (a *App) isStartupRegistered() bool {
	if runtime.GOOS != "windows" {
		return false
	}
	cmd := hiddenCmd("reg", "query", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", "MinecraftModUpdater")
	out, err := cmd.CombinedOutput()
	if err != nil {
		return false
	}
	return strings.Contains(strings.ToLower(string(out)), "minecraftmodupdater")
}

func selectFolder() (string, error) {
	if runtime.GOOS != "windows" {
		return "", fmt.Errorf("folder picker is available on Windows only")
	}
	script := `
Add-Type -AssemblyName System.Windows.Forms
$f = New-Object System.Windows.Forms.FolderBrowserDialog
$f.Description = 'Select Minecraft mods folder'
$f.ShowNewFolderButton = $true
if ($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $f.SelectedPath }`
	cmd := hiddenCmd("powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", script)
	out, err := cmd.CombinedOutput()
	if err != nil {
		log.Println("folder picker failed:", string(out), err)
		return "", fmt.Errorf("folder picker failed")
	}
	return strings.TrimSpace(string(out)), nil
}

func openBrowser(url string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = hiddenCmd("rundll32", "url.dll,FileProtocolHandler", url)
	case "darwin":
		cmd = exec.Command("open", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	_ = cmd.Start()
}

func openPath(path string) {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "windows":
		cmd = hiddenCmd("rundll32", "url.dll,FileProtocolHandler", path)
	case "darwin":
		cmd = exec.Command("open", path)
	default:
		cmd = exec.Command("xdg-open", path)
	}
	_ = cmd.Start()
}

var quitting int32

func quitApp(a *App) {
	if !atomic.CompareAndSwapInt32(&quitting, 0, 1) {
		return
	}
	if a != nil && a.server != nil {
		_ = a.server.Shutdown(context.Background())
	}
	time.Sleep(200 * time.Millisecond)
	os.Exit(0)
}

var globalApp *App

// handleCheckAppUpdate forces an immediate re-check of the server version.
func (a *App) handleCheckAppUpdate(w http.ResponseWriter, r *http.Request) {
	go a.checkSelfUpdate()
	writeJSON(w, map[string]any{"ok": true, "message": "Checking for app update..."})
}
func (a *App) selfUpdateLoop(ctx context.Context) {
	// First check shortly after startup
	select {
	case <-ctx.Done():
		return
	case <-time.After(15 * time.Second):
	}
	a.checkSelfUpdate()

	ticker := time.NewTicker(10 * time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			a.checkSelfUpdate()
		}
	}
}

// effectiveVersion returns the version we should compare against the server.
// After a self-update the new exe writes InstalledVersion to config.
// If not set, fall back to the build-time embedded clientVersion.
func (a *App) effectiveVersion() string {
	a.mu.Lock()
	v := a.cfg.InstalledVersion
	a.mu.Unlock()
	if v != "" {
		return v
	}
	return clientVersion
}

// checkSelfUpdate hits /api/client/version on the backend and updates stats.
func (a *App) checkSelfUpdate() {
	a.mu.Lock()
	backend := strings.TrimRight(a.cfg.BackendURL, "/")
	a.mu.Unlock()
	if backend == "" {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, "GET", backend+"/api/client/version", nil)
	resp, err := a.client.Do(req)
	if err != nil {
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return
	}
	var info struct {
		Version   string `json:"version"`
		Available bool   `json:"available"`
		Size      int64  `json:"size"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&info); err != nil {
		return
	}
	newer := info.Available && info.Version != "" && versionNewerThan(info.Version, a.effectiveVersion())
	a.mu.Lock()
	a.stats.SelfUpdateAvailable = newer
	a.stats.SelfUpdateVersion = info.Version
	a.mu.Unlock()
	if newer {
		log.Printf("self-update available: server=%s current=%s", info.Version, clientVersion)
	}
}

// versionNewerThan returns true if candidate is strictly newer than current.
// Compares dot-separated numeric segments lexicographically after zero-padding.
func versionNewerThan(candidate, current string) bool {
	parse := func(v string) [4]int {
		var parts [4]int
		for i, s := range strings.SplitN(v, ".", 4) {
			if i >= 4 {
				break
			}
			n := 0
			for _, c := range s {
				if c >= '0' && c <= '9' {
					n = n*10 + int(c-'0')
				}
			}
			parts[i] = n
		}
		return parts
	}
	c := parse(candidate)
	cur := parse(current)
	for i := range c {
		if c[i] > cur[i] {
			return true
		}
		if c[i] < cur[i] {
			return false
		}
	}
	return false
}

// performSelfUpdate downloads the new exe and uses PowerShell to replace it after exit.
// PowerShell runs windowless and detached — no CMD console, no spam.
func (a *App) performSelfUpdate(ver string) error {
	if runtime.GOOS != "windows" {
		return fmt.Errorf("self-update only supported on Windows")
	}

	a.mu.Lock()
	backend := strings.TrimRight(a.cfg.BackendURL, "/")
	exePath := a.exePath
	a.mu.Unlock()

	if real, err := filepath.EvalSymlinks(exePath); err == nil {
		exePath = real
	}
	exePath, _ = filepath.Abs(exePath)

	if backend == "" || exePath == "" {
		return fmt.Errorf("backend or exe path not set")
	}

	newExePath := exePath + ".new"
	_ = os.Remove(newExePath)

	log.Printf("self-update: downloading to %s", newExePath)

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()

	a.mu.Lock()
	a.stats.CurrentStage = "Downloading client update"
	a.stats.UpdateProgress = 5
	a.mu.Unlock()

	_, err := downloadWithProgress(a.client, ctx, backend+"/download/client", newExePath, 0,
		func(downloaded, total, speed int64) {
			progress := 10
			if total > 0 {
				pct := int(downloaded * 85 / total)
				if pct > 85 { pct = 85 }
				progress = 10 + pct
			}
			a.mu.Lock()
			a.stats.CurrentStage = fmt.Sprintf("Downloading client update (%s)", humanBytes(downloaded))
			a.stats.UpdateProgress = progress
			a.stats.DownloadSpeed = speed
			a.mu.Unlock()
		})
	if err != nil {
		_ = os.Remove(newExePath)
		return fmt.Errorf("download failed: %w", err)
	}

	if fi, err := os.Stat(newExePath); err != nil || fi.Size() < 1024 {
		_ = os.Remove(newExePath)
		return fmt.Errorf("downloaded file is invalid")
	}

	a.mu.Lock()
	a.stats.CurrentStage = "Restarting with new version..."
	a.stats.UpdateProgress = 99
	a.stats.DownloadSpeed = 0
	// Persist the new version so after restart the app knows it's up to date
	a.cfg.InstalledVersion = ver
	a.save()
	a.mu.Unlock()

	pid := os.Getpid()

	// Build PowerShell script that:
	// 1. Waits for our PID to fully exit
	// 2. Waits extra 1s for port to be freed
	// 3. Moves .new over old exe (retry 15x)
	// 4. Launches the new exe normally (not --background so it opens the panel)
	newEscaped := strings.ReplaceAll(newExePath, `'`, `''`)
	oldEscaped := strings.ReplaceAll(exePath, `'`, `''`)

	ps1 := fmt.Sprintf(`
$newExe = '%s'
$oldExe = '%s'
$targetPid = %d
while ($null -ne (Get-Process -Id $targetPid -ErrorAction SilentlyContinue)) {
    Start-Sleep -Milliseconds 200
}
Start-Sleep -Seconds 1
$moved = $false
for ($i = 0; $i -lt 15; $i++) {
    try {
        Move-Item -Force -LiteralPath $newExe -Destination $oldExe
        $moved = $true
        break
    } catch {
        Start-Sleep -Seconds 1
    }
}
if ($moved) {
    Start-Process -FilePath $oldExe
}
`, newEscaped, oldEscaped, pid)

	// Encode as UTF-16LE Base64 so we can use -EncodedCommand.
	// This avoids -File (which needs a .ps1 file and can show a window),
	// ExecutionPolicy issues, and path-with-spaces problems entirely.
	utf16 := encodeUTF16LE(ps1)
	b64 := base64Encode(utf16)

	log.Printf("self-update: launching encoded PowerShell updater pid=%d", pid)

	cmd := exec.Command("powershell",
		"-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
		"-EncodedCommand", b64)
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	if err := cmd.Start(); err != nil {
		_ = os.Remove(newExePath)
		return fmt.Errorf("cannot launch updater: %w", err)
	}
	go func() { _ = cmd.Wait() }()

	go func() {
		time.Sleep(1500 * time.Millisecond)
		quitApp(a)
	}()
	return nil
}

// encodeUTF16LE converts a UTF-8 string to UTF-16LE bytes (required by PowerShell -EncodedCommand)
func encodeUTF16LE(s string) []byte {
	runes := []rune(s)
	buf := make([]byte, len(runes)*2)
	for i, r := range runes {
		buf[i*2] = byte(r)
		buf[i*2+1] = byte(r >> 8)
	}
	return buf
}

// base64Encode returns the standard base64 encoding of b
func base64Encode(b []byte) string {
	const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	out := make([]byte, 0, ((len(b)+2)/3)*4)
	for i := 0; i < len(b); i += 3 {
		var v uint32
		n := 0
		for j := 0; j < 3 && i+j < len(b); j++ {
			v |= uint32(b[i+j]) << (16 - j*8)
			n++
		}
		out = append(out, chars[(v>>18)&0x3F], chars[(v>>12)&0x3F])
		if n > 1 {
			out = append(out, chars[(v>>6)&0x3F])
		} else {
			out = append(out, '=')
		}
		if n > 2 {
			out = append(out, chars[v&0x3F])
		} else {
			out = append(out, '=')
		}
	}
	return string(out)
}

// handleSelfUpdate triggers the self-update immediately.
func (a *App) handleSelfUpdate(w http.ResponseWriter, r *http.Request) {
	a.mu.Lock()
	avail := a.stats.SelfUpdateAvailable
	ver := a.stats.SelfUpdateVersion
	a.mu.Unlock()
	if !avail {
		writeJSON(w, map[string]any{"ok": false, "message": "No update available"})
		return
	}
	writeJSON(w, map[string]any{"ok": true, "message": "Downloading and applying update to v" + ver + "..."})
	go func() {
		if err := a.performSelfUpdate(ver); err != nil {
			log.Println("self-update failed:", err)
			a.mu.Lock()
			a.stats.CurrentStage = "Self-update failed: " + err.Error()
			a.stats.UpdateProgress = 0
			a.mu.Unlock()
		}
	}()
}

// --- Win32 tray ---
var (
	user32                  = syscall.NewLazyDLL("user32.dll")
	shell32                 = syscall.NewLazyDLL("shell32.dll")
	kernel32                = syscall.NewLazyDLL("kernel32.dll")
	gdi32                   = syscall.NewLazyDLL("gdi32.dll")
	procRegisterClassEx     = user32.NewProc("RegisterClassExW")
	procCreateWindowEx      = user32.NewProc("CreateWindowExW")
	procDefWindowProc       = user32.NewProc("DefWindowProcW")
	procGetMessage          = user32.NewProc("GetMessageW")
	procTranslateMessage    = user32.NewProc("TranslateMessage")
	procDispatchMessage     = user32.NewProc("DispatchMessageW")
	procPostQuitMessage     = user32.NewProc("PostQuitMessage")
	procLoadImage           = user32.NewProc("LoadImageW")
	procLoadCursor          = user32.NewProc("LoadCursorW")
	procCreatePopupMenu     = user32.NewProc("CreatePopupMenu")
	procAppendMenu          = user32.NewProc("AppendMenuW")
	procSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	procTrackPopupMenu      = user32.NewProc("TrackPopupMenu")
	procDestroyMenu         = user32.NewProc("DestroyMenu")
	procShellNotifyIcon     = shell32.NewProc("Shell_NotifyIconW")
	procGetModuleHandle     = kernel32.NewProc("GetModuleHandleW")
	procGetDC               = user32.NewProc("GetDC")
	procReleaseDC           = user32.NewProc("ReleaseDC")
	procCreateCompatibleDC  = gdi32.NewProc("CreateCompatibleDC")
	procDeleteDC            = gdi32.NewProc("DeleteDC")
	procCreateCompatibleBitmap = gdi32.NewProc("CreateCompatibleBitmap")
	procSelectObject        = gdi32.NewProc("SelectObject")
	procDeleteObject        = gdi32.NewProc("DeleteObject")
	procCreateSolidBrush    = gdi32.NewProc("CreateSolidBrush")
	procFillRect            = user32.NewProc("FillRect")
	procEllipse             = gdi32.NewProc("Ellipse")
	procPie                 = gdi32.NewProc("Pie")
	procCreatePen           = gdi32.NewProc("CreatePen")
	procMoveToEx            = gdi32.NewProc("MoveToEx")
	procLineTo              = gdi32.NewProc("LineTo")
	procSetBkMode           = gdi32.NewProc("SetBkMode")
	procCreateIconIndirect  = user32.NewProc("CreateIconIndirect")
	procDestroyIcon         = user32.NewProc("DestroyIcon")
	procCreateBitmap        = gdi32.NewProc("CreateBitmap")
)

const (
	WM_DESTROY      = 0x0002
	WM_COMMAND      = 0x0111
	WM_USER         = 0x0400
	WM_LBUTTONUP    = 0x0202
	WM_RBUTTONUP    = 0x0205
	NIM_ADD         = 0x00000000
	NIM_MODIFY      = 0x00000001
	NIM_DELETE      = 0x00000002
	NIM_SETVERSION  = 0x00000004
	NOTIFYICON_VERSION_4 = 4
	NOTIFYICON_VERSION   = 3
	NIF_MESSAGE     = 0x00000001
	NIF_ICON        = 0x00000002
	NIF_TIP         = 0x00000004
	IDI_APPLICATION = 32512
	IDC_ARROW       = 32512
	IMAGE_ICON      = 1
	LR_DEFAULTSIZE  = 0x00000040
	LR_DEFAULTCOLOR = 0x00000000
	TPM_BOTTOMALIGN = 0x0020
	TPM_LEFTALIGN   = 0x0000
	MF_STRING       = 0x0000
	MF_SEPARATOR    = 0x0800
	PS_SOLID        = 0
	TRANSPARENT     = 1
	trayMsg         = WM_USER + 1
	cmdOpen         = 1001
	cmdExit         = 1002
)

// ICONINFO is used by CreateIconIndirect
type ICONINFO struct {
	FIcon    int32
	XHotspot uint32
	YHotspot uint32
	HbmMask  uintptr
	HbmColor uintptr
}

// TrayState represents which icon to show
type TrayState int

const (
	TrayIdle        TrayState = iota // green circle — all good
	TrayDownloading                  // blue spinner — busy
	TrayError                        // red X — last action failed
)

// trayIconState is written by the app loop, read by the tray goroutine
var (
	trayIconState     int32 // atomic: 0=idle, 1=downloading, 2=error
	traySpinFrame     int32 // atomic: 0-7 animation frame
	trayHwnd          uintptr
)

func setTrayState(s TrayState) {
	atomic.StoreInt32(&trayIconState, int32(s))
}

// loadAppIcon loads the embedded application icon (used for window class only).
func loadAppIcon(hinst uintptr) uintptr {
	icon, _, _ := procLoadImage.Call(
		hinst, 1, IMAGE_ICON, 0, 0, LR_DEFAULTSIZE|LR_DEFAULTCOLOR,
	)
	if icon == 0 {
		icon, _, _ = procLoadImage.Call(
			0, uintptr(IDI_APPLICATION), IMAGE_ICON, 0, 0, LR_DEFAULTSIZE|LR_DEFAULTCOLOR,
		)
	}
	return icon
}

// colorToBGR converts 0xRRGGBB to Windows COLORREF (0x00BBGGRR)
func colorToBGR(rgb uint32) uintptr {
	r := (rgb >> 16) & 0xFF
	g := (rgb >> 8) & 0xFF
	b := rgb & 0xFF
	return uintptr(b<<16 | g<<8 | r)
}

// buildTrayIcon draws the original app icon with a small status dot
// in the bottom-right corner.
// Idle → no dot (plain icon), Downloading → blue pulsing dot, Error → red dot.
func buildTrayIcon(state TrayState, frame int) uintptr {
	const sz = 32

	screenDC, _, _ := procGetDC.Call(0)
	memDC, _, _ := procCreateCompatibleDC.Call(screenDC)
	bmp, _, _ := procCreateCompatibleBitmap.Call(screenDC, sz, sz)
	procSelectObject.Call(memDC, bmp)
	procReleaseDC.Call(0, screenDC)

	// Fill transparent background first
	blackBrush, _, _ := procCreateSolidBrush.Call(0x00000000)
	var rc RECT
	rc.Right, rc.Bottom = sz, sz
	procFillRect.Call(memDC, uintptr(unsafe.Pointer(&rc)), blackBrush)
	procDeleteObject.Call(blackBrush)

	// Draw the original embedded icon onto our DC
	hinst, _, _ := procGetModuleHandle.Call(0)
	baseIcon := loadAppIcon(hinst)
	if baseIcon != 0 {
		procDrawIconEx := user32.NewProc("DrawIconEx")
		// DI_NORMAL = 0x0003, draw icon at full 32x32
		procDrawIconEx.Call(memDC, 0, 0, baseIcon, sz, sz, 0, 0, 3)
		// Don't destroy baseIcon — it's loaded with LR_SHARED semantics and cached
	}

	procSetBkMode.Call(memDC, TRANSPARENT)

	// Dot geometry: bottom-right corner, 9px diameter
	const dotSize = 9
	const dotX = sz - dotSize - 1 // right-align with 1px margin
	const dotY = sz - dotSize - 1 // bottom-align with 1px margin

	switch state {
	case TrayIdle:
		// No dot — plain icon is enough

	case TrayDownloading:
		// Blue dot. Pulses: frames 0-3 bright, 4-7 slightly dimmer
		var dotColor, borderColor uint32
		if frame < 4 {
			dotColor = 0x60a5fa  // bright blue
			borderColor = 0x2563eb
		} else {
			dotColor = 0x3b82f6  // slightly dimmer
			borderColor = 0x1d4ed8
		}
		// White border ring around dot (makes it pop on any background)
		borderBrush, _, _ := procCreateSolidBrush.Call(colorToBGR(0xffffff))
		borderPen, _, _ := procCreatePen.Call(PS_SOLID, 0, colorToBGR(0xffffff))
		procSelectObject.Call(memDC, borderBrush)
		procSelectObject.Call(memDC, borderPen)
		procEllipse.Call(memDC, dotX-1, dotY-1, dotX+dotSize+1, dotY+dotSize+1)
		procDeleteObject.Call(borderBrush)
		procDeleteObject.Call(borderPen)
		// Filled blue dot
		dotBrush, _, _ := procCreateSolidBrush.Call(colorToBGR(dotColor))
		dotPen, _, _ := procCreatePen.Call(PS_SOLID, 0, colorToBGR(borderColor))
		procSelectObject.Call(memDC, dotBrush)
		procSelectObject.Call(memDC, dotPen)
		procEllipse.Call(memDC, dotX, dotY, dotX+dotSize, dotY+dotSize)
		procDeleteObject.Call(dotBrush)
		procDeleteObject.Call(dotPen)

	case TrayError:
		// White border ring
		borderBrush, _, _ := procCreateSolidBrush.Call(colorToBGR(0xffffff))
		borderPen, _, _ := procCreatePen.Call(PS_SOLID, 0, colorToBGR(0xffffff))
		procSelectObject.Call(memDC, borderBrush)
		procSelectObject.Call(memDC, borderPen)
		procEllipse.Call(memDC, dotX-1, dotY-1, dotX+dotSize+1, dotY+dotSize+1)
		procDeleteObject.Call(borderBrush)
		procDeleteObject.Call(borderPen)
		// Red dot
		dotBrush, _, _ := procCreateSolidBrush.Call(colorToBGR(0xef4444))
		dotPen, _, _ := procCreatePen.Call(PS_SOLID, 0, colorToBGR(0xdc2626))
		procSelectObject.Call(memDC, dotBrush)
		procSelectObject.Call(memDC, dotPen)
		procEllipse.Call(memDC, dotX, dotY, dotX+dotSize, dotY+dotSize)
		procDeleteObject.Call(dotBrush)
		procDeleteObject.Call(dotPen)
	}

	// Build mask bitmap (all-black = fully opaque)
	maskBmp, _, _ := procCreateBitmap.Call(sz, sz, 1, 1, 0)
	ii := ICONINFO{FIcon: 1, HbmMask: maskBmp, HbmColor: bmp}
	hicon, _, _ := procCreateIconIndirect.Call(uintptr(unsafe.Pointer(&ii)))

	procDeleteObject.Call(bmp)
	procDeleteObject.Call(maskBmp)
	procDeleteDC.Call(memDC)

	return hicon
}

// RECT for FillRect
type RECT struct{ Left, Top, Right, Bottom int32 }

type POINT struct{ X, Y int32 }
type MSG struct {
	Hwnd           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	Pt             POINT
	LPrivate       uint32
}
type WNDCLASSEX struct {
	CbSize        uint32
	Style         uint32
	LpfnWndProc   uintptr
	CbClsExtra    int32
	CbWndExtra    int32
	HInstance     uintptr
	HIcon         uintptr
	HCursor       uintptr
	HbrBackground uintptr
	LpszMenuName  *uint16
	LpszClassName *uint16
	HIconSm       uintptr
}
type NOTIFYICONDATA struct {
	CbSize           uint32
	HWnd             uintptr
	UID              uint32
	UFlags           uint32
	UCallbackMessage uint32
	HIcon            uintptr
	SzTip            [128]uint16
	DwState          uint32
	DwStateMask      uint32
	SzInfo           [256]uint16
	UVersion         uint32 // timeout or version depending on flags
	SzInfoTitle      [64]uint16
	DwInfoFlags      uint32
}

const (
	WM_APP_UPDATE_ICON = WM_USER + 2 // posted by goroutine to trigger icon rebuild on UI thread
)

// trayIconRequest is the pending icon state set by the goroutine, read by wndProc
var (
	trayPendingState int32 // atomic TrayState
	trayPendingFrame int32 // atomic frame 0-7
)

func runTray() {
	className, _ := syscall.UTF16PtrFromString("MinecraftModUpdaterTray")
	title, _ := syscall.UTF16PtrFromString("MinecraftModUpdater")
	hinst, _, _ := procGetModuleHandle.Call(0)
	appIcon := loadAppIcon(hinst)
	cursor, _, _ := procLoadCursor.Call(0, uintptr(IDC_ARROW))
	wc := WNDCLASSEX{
		CbSize:        uint32(unsafe.Sizeof(WNDCLASSEX{})),
		LpfnWndProc:   syscall.NewCallback(wndProc),
		HInstance:     hinst, HIcon: appIcon, HCursor: cursor,
		LpszClassName: className, HIconSm: appIcon,
	}
	procRegisterClassEx.Call(uintptr(unsafe.Pointer(&wc)))
	hwnd, _, _ := procCreateWindowEx.Call(0,
		uintptr(unsafe.Pointer(className)),
		uintptr(unsafe.Pointer(title)),
		0, 0, 0, 0, 0, 0, 0, hinst, 0)
	trayHwnd = hwnd

	// Build initial idle icon on this thread
	currentIcon := buildTrayIcon(TrayIdle, 0)
	nid := NOTIFYICONDATA{
		CbSize: uint32(unsafe.Sizeof(NOTIFYICONDATA{})),
		HWnd: hwnd, UID: 1,
		UFlags:           NIF_MESSAGE | NIF_ICON | NIF_TIP,
		UCallbackMessage: trayMsg,
		HIcon:            currentIcon,
	}
	tip, _ := syscall.UTF16FromString("Minecraft Mod Updater")
	copy(nid.SzTip[:], tip)
	procShellNotifyIcon.Call(NIM_ADD, uintptr(unsafe.Pointer(&nid)))
	// NIM_SETVERSION with VERSION 3 — enables balloon tips and reliable click messages
	// without changing the lParam format (VERSION_4 breaks lParam meaning)
	nid.UVersion = NOTIFYICON_VERSION
	procShellNotifyIcon.Call(NIM_SETVERSION, uintptr(unsafe.Pointer(&nid)))

	// Store nid pointer so wndProc can access it for NIM_MODIFY
	trayNid = &nid
	trayCurrentIcon = &currentIcon

	// Goroutine only decides WHAT state we're in and posts a message —
	// no GDI calls here, keeping all Win32 drawing on the message-loop thread
	procPostMessage := user32.NewProc("PostMessageW")
	go func() {
		var lastState TrayState = TrayIdle
		var lastFrame int = -1
		ticker := time.NewTicker(125 * time.Millisecond)
		defer ticker.Stop()
		for range ticker.C {
			if globalApp == nil || trayHwnd == 0 {
				continue
			}
			globalApp.mu.Lock()
			busy := globalApp.stats.Busy
			lastResult := globalApp.stats.LastResult
			globalApp.mu.Unlock()

			var newState TrayState
			if busy {
				newState = TrayDownloading
			} else if strings.Contains(strings.ToLower(lastResult), "failed") ||
				strings.Contains(strings.ToLower(lastResult), "error") {
				newState = TrayError
			} else {
				newState = TrayIdle
			}

			frame := 0
			if newState == TrayDownloading {
				frame = int(atomic.AddInt32(&traySpinFrame, 1) % 8)
			}

			if newState == lastState && (newState != TrayDownloading || frame == lastFrame) {
				continue
			}
			lastState = newState
			lastFrame = frame

			// Publish to atomics, then wake the message loop
			atomic.StoreInt32(&trayPendingState, int32(newState))
			atomic.StoreInt32(&trayPendingFrame, int32(frame))
			procPostMessage.Call(trayHwnd, WM_APP_UPDATE_ICON, 0, 0)
		}
	}()

	var msg MSG
	for {
		ret, _, _ := procGetMessage.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(ret) <= 0 {
			break
		}
		procTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		procDispatchMessage.Call(uintptr(unsafe.Pointer(&msg)))
	}
	procShellNotifyIcon.Call(NIM_DELETE, uintptr(unsafe.Pointer(&nid)))
	procDestroyIcon.Call(currentIcon)
}

// trayNid and trayCurrentIcon are set by runTray and read/written by wndProc (same thread)
var trayNid         *NOTIFYICONDATA
var trayCurrentIcon *uintptr

func wndProc(hwnd uintptr, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case trayMsg:
		// With NOTIFYICON_VERSION (3): the event message is directly in lParam
		switch uint32(lParam) {
		case WM_LBUTTONUP:
			openBrowser("http://" + listenAddr)
		case WM_RBUTTONUP:
			showTrayMenu(hwnd)
		}
		return 0

	case WM_APP_UPDATE_ICON:
		// Called on the message-loop thread — safe to do GDI and Shell_NotifyIcon here
		if trayNid == nil || trayCurrentIcon == nil {
			return 0
		}
		state := TrayState(atomic.LoadInt32(&trayPendingState))
		frame := int(atomic.LoadInt32(&trayPendingFrame))

		newIcon := buildTrayIcon(state, frame)

		var tipStr string
		switch state {
		case TrayDownloading:
			if globalApp != nil {
				globalApp.mu.Lock()
				tipStr = "Mod Updater — " + globalApp.stats.CurrentStage
				globalApp.mu.Unlock()
			}
		case TrayError:
			if globalApp != nil {
				globalApp.mu.Lock()
				tipStr = "Mod Updater — " + globalApp.stats.LastResult
				globalApp.mu.Unlock()
			}
		default:
			tipStr = "Minecraft Mod Updater — Idle"
		}
		if len(tipStr) > 127 {
			tipStr = tipStr[:127]
		}

		trayNid.HIcon = newIcon
		tipW, _ := syscall.UTF16FromString(tipStr)
		for i := range trayNid.SzTip {
			trayNid.SzTip[i] = 0
		}
		copy(trayNid.SzTip[:], tipW)
		procShellNotifyIcon.Call(NIM_MODIFY, uintptr(unsafe.Pointer(trayNid)))

		if *trayCurrentIcon != 0 && *trayCurrentIcon != newIcon {
			procDestroyIcon.Call(*trayCurrentIcon)
		}
		*trayCurrentIcon = newIcon
		return 0

	case WM_COMMAND:
		switch int(wParam & 0xffff) {
		case cmdOpen:
			openBrowser("http://" + listenAddr)
		case cmdExit:
			go quitApp(globalApp)
		}
		return 0

	case WM_DESTROY:
		procPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := procDefWindowProc.Call(hwnd, uintptr(msg), wParam, lParam)
	return r
}

func showTrayMenu(hwnd uintptr) {
	menu, _, _ := procCreatePopupMenu.Call()
	txt1, _ := syscall.UTF16PtrFromString("Open Web Panel")
	txt2, _ := syscall.UTF16PtrFromString("Force Close App")
	procAppendMenu.Call(menu, MF_STRING, cmdOpen, uintptr(unsafe.Pointer(txt1)))
	procAppendMenu.Call(menu, MF_SEPARATOR, 0, 0)
	procAppendMenu.Call(menu, MF_STRING, cmdExit, uintptr(unsafe.Pointer(txt2)))
	procSetForegroundWindow.Call(hwnd)
	var pt POINT
	user32.NewProc("GetCursorPos").Call(uintptr(unsafe.Pointer(&pt)))
	procTrackPopupMenu.Call(menu, TPM_LEFTALIGN|TPM_BOTTOMALIGN, uintptr(pt.X), uintptr(pt.Y), 0, hwnd, 0)
	procDestroyMenu.Call(menu)
}

var pageHTML = `
<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<title>Minecraft Mod Updater</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<style>
:root{
  --bg:#0b1020;
  --panel:#121a2b;
  --panel2:#0f1727;
  --border:#25314b;
  --text:#eef3ff;
  --muted:#96a3bd;
  --accent:#6ea8fe;
  --accent2:#7c3aed;
  --good:#22c55e;
  --warn:#ef4444;
  --soft:#1d2940;
}
*{box-sizing:border-box}
body{
  margin:0;
  font-family:Inter,Segoe UI,Arial,sans-serif;
  color:var(--text);
  background:
    radial-gradient(circle at top left, rgba(110,168,254,.16), transparent 22%),
    radial-gradient(circle at top right, rgba(124,58,237,.14), transparent 20%),
    linear-gradient(180deg,#0a0f1a,#0d1422 45%,#0a0f1a);
}
.wrap{max-width:1280px;margin:26px auto;padding:0 18px 24px}
.topbar{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;margin-bottom:18px}
.title h1{margin:0;font-size:32px;letter-spacing:.3px}
.title p{margin:8px 0 0;color:var(--muted)}
.badges{display:flex;gap:10px;flex-wrap:wrap}
.badge{padding:10px 14px;border-radius:999px;background:rgba(110,168,254,.14);border:1px solid rgba(110,168,254,.24);color:#dbe8ff;font-size:13px}
.grid{display:grid;grid-template-columns:1.08fr .92fr;gap:18px}
.card{
  background:linear-gradient(180deg,rgba(18,26,43,.96),rgba(14,21,35,.98));
  border:1px solid var(--border);
  border-radius:22px;
  padding:20px;
  box-shadow:0 22px 50px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.03);
}
.section-title{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px}
.section-title h2{margin:0;font-size:20px}
.section-title span{color:var(--muted);font-size:13px}
.stack{display:flex;flex-direction:column;gap:14px}
label{display:block;font-size:13px;color:var(--muted);margin-bottom:7px}
input{
  width:100%;padding:14px 15px;border-radius:14px;border:1px solid #33415f;
  background:#091120;color:var(--text);outline:none;font-size:14px;
}
input:focus{border-color:var(--accent);box-shadow:0 0 0 4px rgba(110,168,254,.13)}
.row{display:flex;gap:10px;align-items:center}
.button-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
button{
  border:0;border-radius:14px;padding:13px 15px;font-weight:700;font-size:14px;
  color:white;cursor:pointer;transition:.18s transform,.18s opacity,.18s background;
  background:linear-gradient(135deg,var(--accent),#3b82f6);
  box-shadow:0 10px 24px rgba(59,130,246,.18);
}
button:hover:not(:disabled){transform:translateY(-1px)}
button.alt{background:linear-gradient(135deg,#3b465a,#53627c)}
button.good{background:linear-gradient(135deg,#16a34a,#22c55e)}
button.warn{background:linear-gradient(135deg,#dc2626,#ef4444)}
button.ghost{background:linear-gradient(135deg,#4c1d95,#7c3aed)}
button.cancel-btn{background:linear-gradient(135deg,#7f1d1d,#ef4444);grid-column:1/-1}
button:disabled{opacity:.45;cursor:not-allowed;transform:none}
.notice{
  border:1px solid #26324b;background:#0a1322;border-radius:16px;padding:14px;
  color:#dbe6fb;min-height:52px;display:flex;align-items:center
}
.meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.info-box{
  background:rgba(10,19,34,.72);border:1px solid #24314a;border-radius:16px;padding:14px
}
.info-box .k{display:block;color:var(--muted);font-size:12px;margin-bottom:6px}
.info-box .v{display:block;font-size:18px;font-weight:700}
.progress-wrap{margin-top:4px}
progress{
  width:100%;height:18px;border:0;border-radius:999px;overflow:hidden;
  appearance:none
}
progress::-webkit-progress-bar{background:#09111f;border-radius:999px}
progress::-webkit-progress-value{background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:999px}
progress::-moz-progress-bar{background:linear-gradient(90deg,var(--accent),var(--accent2))}
.stats{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.stat{
  background:rgba(10,19,34,.74);border:1px solid #25314b;border-radius:16px;padding:12px 13px
}
.stat .k{display:block;color:var(--muted);font-size:12px;margin-bottom:7px}
.stat .v{display:block;font-size:14px;font-weight:700;word-break:break-word}
.footer-note{margin-top:12px;color:var(--muted);font-size:12px}
button.update-btn{background:linear-gradient(135deg,#4c1d95,#7c3aed);white-space:nowrap;padding:10px 16px}
/* Variant pills */
.vpill{border:1px solid #33415f;border-radius:10px;padding:8px 14px;font-size:13px;font-weight:700;
  color:var(--muted);background:#091120;cursor:pointer;transition:.15s;display:flex;align-items:center;gap:6px}
.vpill:hover{border-color:var(--accent);color:var(--accent)}
.vpill.active{border-color:var(--accent);color:var(--accent);background:rgba(110,168,254,.1)}
.vpill .vdot{width:6px;height:6px;border-radius:50%;background:var(--muted)}
.vpill.active .vdot{background:var(--accent)}
/* Patch notes */
.patch-wrap{margin-top:6px}
#patch-panel{border-radius:16px;overflow:hidden;border:1px solid #25314b}
.patch-header{padding:10px 14px;background:#0a1322;color:var(--muted);font-size:12px;border-bottom:1px solid #25314b;display:flex;justify-content:space-between;align-items:center}
.patch-list{max-height:240px;overflow-y:auto;scrollbar-width:thin;scrollbar-color:#25314b transparent}.patch-list::-webkit-scrollbar{width:4px}.patch-list::-webkit-scrollbar-track{background:transparent}.patch-list::-webkit-scrollbar-thumb{background:#25314b;border-radius:4px}.patch-list::-webkit-scrollbar-thumb:hover{background:#33415f}
.patch-entry{
  display:flex;align-items:center;gap:10px;padding:8px 14px;font-size:13px;font-weight:600;
  border-bottom:1px solid rgba(37,49,75,.5);
}
.patch-entry:last-child{border-bottom:0}
.patch-entry.added{background:rgba(22,163,74,.18);color:#4ade80}
.patch-entry.removed{background:rgba(220,38,38,.18);color:#f87171}
.patch-tag{
  font-size:11px;font-weight:700;padding:2px 7px;border-radius:6px;white-space:nowrap;
}
.patch-tag.added{background:#16a34a;color:#fff}
.patch-tag.removed{background:#dc2626;color:#fff}
.patch-empty{padding:16px;color:var(--muted);font-size:13px;text-align:center}
.speed-badge{font-size:12px;font-weight:700;color:#6ea8fe;background:rgba(110,168,254,.12);border:1px solid rgba(110,168,254,.2);padding:2px 8px;border-radius:8px;display:none}
/* Sparkline */
.sparkline-wrap{display:none;flex-direction:column;gap:6px;background:rgba(10,19,34,.72);border:1px solid #24314a;border-radius:16px;padding:12px 14px}
.sparkline-wrap.active{display:flex}
.sparkline-row{display:flex;justify-content:space-between;align-items:center}
.sparkline-label{font-size:12px;color:var(--muted)}
.sparkline-speed{font-size:15px;font-weight:700;color:#6ea8fe}
.sparkline-peak{font-size:11px;color:var(--muted)}
canvas#sparkline{width:100%;height:52px;border-radius:8px;display:block}
@media (max-width: 980px){
  .grid{grid-template-columns:1fr}
  .meta-grid,.stats,.button-grid{grid-template-columns:1fr}
  .topbar{flex-direction:column;align-items:flex-start}
}
</style>
</head>
<body>
<div class="wrap">
  <div class="topbar">
    <div class="title">
      <h1>Minecraft Mod Updater</h1>
      <p>Browser panel client with persistent config, managed-mod tracking, and 60-second auto-pull.</p>
    </div>
    <div class="badges">
      <div class="badge" id="badgeListening">Listening: -</div>
      <div class="badge" id="badgeUpdate">Update found: -</div>
      <div class="badge" id="badgeCountdown">Next pull: -</div>
    </div>
  </div>

  <div class="grid">
    <section class="card">
      <div class="section-title">
        <h2>Control panel</h2>
        <span>Settings and actions</span>
      </div>

      <div class="stack">
        <div>
          <label>Backend URL</label>
          <input id="backend" placeholder="http://82.137.73.40:8080"/>
        </div>

        <div>
          <label>Modpack variant</label>
          <div id="variant-pills" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:4px"></div>
          <div style="font-size:12px;color:var(--muted)" id="variant-hint">Loading variants from backend...</div>
        </div>

        <div>
          <label>Minecraft mods folder</label>
          <div class="row">
            <input id="mods" placeholder="Select your mods folder"/>
            <button class="alt" id="btn-browse" onclick="selectFolder()">Browse...</button>
          </div>
        </div>

        <div class="button-grid">
          <button id="btn-save" onclick="saveSettings()">Save Settings</button>
          <button id="btn-check" onclick="checkNow()">Check Now / Pull Update</button>
          <button id="btn-repull" class="ghost" onclick="repull()">Repull Latest</button>
          <button id="btn-startup" class="alt" onclick="registerStartup()">Register Startup</button>
          <button id="btn-listen-start" class="good" onclick="startListening()">Start Listening</button>
          <button id="btn-listen-stop" class="warn" onclick="stopListening()">Stop Listening</button>
          <button id="btn-logs" class="alt" onclick="openLogs()">Open Logs</button>
          <button id="btn-cancel" class="cancel-btn" onclick="cancelTask()" style="display:none">⛔ Cancel Current Task</button>
        </div>

        <div class="notice" id="msg">Ready.</div>

        <div class="meta-grid">
          <div class="info-box">
            <span class="k">Current stage</span>
            <span class="v" id="current_stage">-</span>
          </div>
          <div class="info-box">
            <span class="k">Update progress</span>
            <span class="v" id="update_progress_text">0%</span>
          </div>
          <div class="info-box">
            <span class="k">Next automatic pull</span>
            <span class="v" id="countdown_big">-</span>
          </div>
          <div class="info-box">
            <span class="k">Found update ID</span>
            <span class="v" id="found_update_id">-</span>
          </div>
        </div>

        <div class="progress-wrap">
          <progress id="update_progress" max="100" value="0"></progress>
        </div>

        <div class="sparkline-wrap" id="sparkline-wrap">
          <div class="sparkline-row">
            <span class="sparkline-label">Download speed — last 30s</span>
            <div style="display:flex;gap:10px;align-items:baseline">
              <span class="sparkline-speed" id="sparkline-current">0 KB/s</span>
              <span class="sparkline-peak" id="sparkline-peak">peak: 0 KB/s</span>
            </div>
          </div>
          <canvas id="sparkline" height="52"></canvas>
        </div>

        <div class="button-grid">
          <button id="btn-bootstrap-clean" class="warn" onclick="bootstrapClean()">First Managed Install</button>
          <button id="btn-bootstrap-keep" class="alt" onclick="bootstrapKeep()">Track Current Folder</button>
        </div>

        <div class="patch-wrap">
          <div id="patch-panel">
            <div class="patch-header">
              <span id="patch-header">Loading patch notes...</span>
              <button onclick="loadPatchNotes()" style="font-size:11px;padding:3px 10px;border-radius:8px;font-weight:600;background:rgba(110,168,254,.15);border:1px solid rgba(110,168,254,.25);color:#6ea8fe;cursor:pointer">↺ Refresh</button>
            </div>
            <div class="patch-list" id="patch-list"><div class="patch-empty">Loading...</div></div>
          </div>
        </div>

        <div class="footer-note">Managed mode: the first managed install never wipes the whole folder. It only replaces files with the same managed names from the incoming pack, then starts tracking them. Later updates delete only updater-managed mods; user-added client mods stay untouched.</div>
      </div>
    </section>

    <section class="card">
      <div class="section-title">
        <h2>Live stats</h2>
        <span>Runtime and backend state</span>
      </div>

      <!-- App version + self-update — always visible at top of stats -->
      <div id="app-update-box" style="border:1px solid #25314b;border-radius:16px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px">
        <div>
          <div style="font-size:12px;color:var(--muted);margin-bottom:3px">App version</div>
          <div style="font-size:15px;font-weight:700" id="app-ver-display">-</div>
          <div id="app-update-status" style="font-size:12px;margin-top:3px;color:var(--muted)">Checking...</div>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0">
          <button id="btn-check-app-update" class="alt" style="padding:9px 13px;font-size:13px" onclick="checkAppUpdate()">Check for update</button>
          <button id="btn-self-update" class="ghost" style="padding:9px 13px;font-size:13px;display:none" onclick="doSelfUpdate()">&#x2B06; Update to v<span id="app-new-ver"></span></button>
        </div>
      </div>

      <div class="stats">
        <div class="stat"><span class="k">Startup registered</span><span class="v" id="startup_registered">-</span></div>
        <div class="stat"><span class="k">Server available_update</span><span class="v" id="server_available">-</span></div>
        <div class="stat"><span class="k">Server latest_update_id</span><span class="v" id="server_latest_id">-</span></div>
        <div class="stat"><span class="k">Local last_update_id</span><span class="v" id="local_last_update_id">-</span></div>
        <div class="stat"><span class="k">Server history count</span><span class="v" id="server_history">-</span></div>
        <div class="stat"><span class="k">Latest package size</span><span class="v" id="server_package_size">-</span></div>
        <div class="stat"><span class="k">Latest file count</span><span class="v" id="server_file_count">-</span></div>
        <div class="stat"><span class="k">Last check</span><span class="v" id="last_check">-</span></div>
        <div class="stat"><span class="k">Last install</span><span class="v" id="last_install">-</span></div>
        <div class="stat"><span class="k">Total checks</span><span class="v" id="total_checks">-</span></div>
        <div class="stat"><span class="k">Total installs</span><span class="v" id="total_installs">-</span></div>
        <div class="stat"><span class="k">Last download size</span><span class="v" id="last_download_size">-</span></div>
        <div class="stat"><span class="k">Managed manifest</span><span class="v" id="has_managed_manifest">-</span></div>
        <div class="stat"><span class="k">Manifest file</span><span class="v" id="manifest_file">-</span></div>
        <div class="stat"><span class="k">First managed install</span><span class="v" id="first_managed_install">-</span></div>
        <div class="stat"><span class="k">Last action</span><span class="v" id="last_action">-</span></div>
        <div class="stat" style="grid-column:1 / -1"><span class="k">Last result</span><span class="v" id="last_result">-</span></div>
      </div>
    </section>
  </div>
</div>

<script>
let editingMods = false;
let editingBackend = false;
const modsEl = document.getElementById('mods');
const backendEl = document.getElementById('backend');
modsEl.addEventListener('focus', ()=> editingMods = true);
modsEl.addEventListener('blur', ()=> editingMods = false);
backendEl.addEventListener('focus', ()=> editingBackend = true);
backendEl.addEventListener('blur', ()=> editingBackend = false);

const busyLocked = ['btn-save','btn-check','btn-repull','btn-startup',
  'btn-listen-start','btn-listen-stop','btn-logs','btn-browse',
  'btn-bootstrap-clean','btn-bootstrap-keep'];

let wasBusy = false;

function setBusy(busy){
  busyLocked.forEach(id => {
    const el = document.getElementById(id);
    if(el) el.disabled = busy;
  });
  document.getElementById('btn-cancel').style.display = busy ? 'block' : 'none';
  // When a task just finished, refresh patch notes automatically
  if(wasBusy && !busy) loadPatchNotes();
  wasBusy = busy;
}

// --- Sparkline ---
const SPARK_POINTS = 30;
const speedHistory = new Array(SPARK_POINTS).fill(0); // ring buffer
let sparkHead = 0;
let sparkPeak = 0;
let sparkActive = false;

function pushSpeed(bps){
  speedHistory[sparkHead] = bps;
  sparkHead = (sparkHead + 1) % SPARK_POINTS;
  if(bps > sparkPeak) sparkPeak = bps;
}

function clearSparkline(){
  speedHistory.fill(0);
  sparkHead = 0;
  sparkPeak = 0;
  sparkActive = false;
  document.getElementById('sparkline-wrap').classList.remove('active');
}

function drawSparkline(currentSpeed){
  const wrap = document.getElementById('sparkline-wrap');
  if(!sparkActive){
    sparkActive = true;
    wrap.classList.add('active');
  }
  document.getElementById('sparkline-current').innerText = bytesPerSec(currentSpeed);
  document.getElementById('sparkline-peak').innerText = 'peak: ' + bytesPerSec(sparkPeak);

  const canvas = document.getElementById('sparkline');
  const dpr = window.devicePixelRatio || 1;
  const W = canvas.offsetWidth || canvas.parentElement.clientWidth;
  const H = 52;
  canvas.width  = W * dpr;
  canvas.height = H * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  // Ordered values oldest→newest
  const vals = [];
  for(let i = 0; i < SPARK_POINTS; i++){
    vals.push(speedHistory[(sparkHead + i) % SPARK_POINTS]);
  }
  const maxVal = Math.max(...vals, 1);
  const pad = 4;
  const stepX = (W - pad * 2) / (SPARK_POINTS - 1);

  // Filled area under the line
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, 'rgba(110,168,254,0.35)');
  grad.addColorStop(1, 'rgba(110,168,254,0.02)');

  ctx.beginPath();
  ctx.moveTo(pad, H);
  for(let i = 0; i < SPARK_POINTS; i++){
    const x = pad + i * stepX;
    const y = H - pad - (vals[i] / maxVal) * (H - pad * 2);
    if(i === 0) ctx.lineTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.lineTo(pad + (SPARK_POINTS - 1) * stepX, H);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  // Line on top
  ctx.beginPath();
  for(let i = 0; i < SPARK_POINTS; i++){
    const x = pad + i * stepX;
    const y = H - pad - (vals[i] / maxVal) * (H - pad * 2);
    if(i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = '#6ea8fe';
  ctx.lineWidth = 1.5;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.stroke();

  // Dot at current tip
  const lastX = pad + (SPARK_POINTS - 1) * stepX;
  const lastY = H - pad - (vals[SPARK_POINTS - 1] / maxVal) * (H - pad * 2);
  ctx.beginPath();
  ctx.arc(lastX, lastY, 3, 0, Math.PI * 2);
  ctx.fillStyle = '#6ea8fe';
  ctx.fill();
}

let sparkClearTimer = null;

function setSpeed(speed, isBusy){
  if(!isBusy){
    // Schedule sparkline clear 3 seconds after download ends — keeps it visible briefly
    if(sparkActive && !sparkClearTimer){
      sparkClearTimer = setTimeout(()=>{ clearSparkline(); sparkClearTimer=null; }, 3000);
    }
    return;
  }
  // Cancel any pending clear if we're downloading again
  if(sparkClearTimer){ clearTimeout(sparkClearTimer); sparkClearTimer=null; }
  // Push 0 when stalled (speed=0 but busy) — shows flatline on graph
  pushSpeed(speed);
  if(speed > 0 || sparkActive){
    drawSparkline(speed);
  }
}

async function api(path, body){
  const r = await fetch(path,{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body || {})
  });
  return await r.json();
}
function setMsg(m){ document.getElementById('msg').innerText = m || ''; }
function set(id, v){ const el=document.getElementById(id); if(el) el.innerText = v; }
function yesno(v){ return v ? 'Yes' : 'No'; }
function bytes(n){
  if(!n) return '0 B';
  if(n < 1024) return n + ' B';
  if(n < 1024*1024) return (n/1024).toFixed(1) + ' KB';
  if(n < 1024*1024*1024) return (n/1024/1024).toFixed(2) + ' MB';
  return (n/1024/1024/1024).toFixed(2) + ' GB';
}
function bytesPerSec(n){
  if(n < 1024) return n + ' B/s';
  if(n < 1024*1024) return (n/1024).toFixed(1) + ' KB/s';
  return (n/1024/1024).toFixed(2) + ' MB/s';
}

let failCount = 0;

async function refresh(){
  try{
    const r = await fetch('/api/ui/status');
    const d = await r.json();
    if(!editingBackend) backendEl.value = d.config.backend_url || '';
    if(!editingMods) modsEl.value = d.config.mods_folder || '';

    set('startup_registered', yesno(d.stats.startup_registered));
    set('listening', yesno(d.stats.listening));
    set('busy', yesno(d.stats.busy));
    set('poll_interval', d.poll_interval + ' sec');
    set('server_available', yesno(d.stats.server_available));
    set('server_latest_id', d.stats.server_latest_update_id || '-');
    set('local_last_update_id', d.config.last_update_id || '-');
    set('server_history', d.stats.server_history_count ?? 0);
    set('server_package_size', bytes(d.stats.server_latest_package_size || 0));
    set('server_file_count', d.stats.server_latest_file_count ?? 0);
    set('last_check', d.stats.last_check || '-');
    set('last_install', d.stats.last_install || '-');
    set('total_checks', d.stats.total_checks ?? 0);
    set('total_installs', d.stats.total_installs ?? 0);
    set('last_download_size', bytes(d.stats.last_download_size || 0));
    set('has_managed_manifest', yesno(d.stats.has_managed_manifest));
    set('manifest_file', d.managed_manifest_path || '-');
    set('first_managed_install', d.stats.first_managed_install || '-');
    set('last_action', d.stats.last_action || '-');
    set('last_result', d.stats.last_result || '-');
    set('current_stage', d.stats.current_stage || 'Idle');
    set('countdown_big', (d.stats.countdown ?? 0) + ' sec');
    set('found_update_id', d.stats.found_update_id || '-');

    document.getElementById('badgeListening').innerText = 'Listening: ' + yesno(d.stats.listening);
    document.getElementById('badgeUpdate').innerText = 'Update found: ' + yesno(d.stats.update_found);
    document.getElementById('badgeCountdown').innerText = 'Next pull: ' + (d.stats.countdown ?? 0) + ' sec';

    setBusy(d.stats.busy);
    setSpeed(d.stats.busy ? (d.stats.download_speed || 0) : 0, d.stats.busy);

    // App version & update box
    const verEl = document.getElementById('app-ver-display');
    const statusEl = document.getElementById('app-update-status');
    const updateBtn = document.getElementById('btn-self-update');
    const newVerSpan = document.getElementById('app-new-ver');
    if(verEl && d.client_version) verEl.innerText = 'v' + d.client_version;
    if(d.stats.self_update_available){
      if(newVerSpan) newVerSpan.innerText = d.stats.self_update_version || '?';
      if(updateBtn)  updateBtn.style.display = 'inline-block';
      if(statusEl){
        statusEl.style.color = '#6ea8fe';
        statusEl.innerText = '\u2B06 v' + (d.stats.self_update_version||'?') + ' available on server';
      }
    } else {
      if(updateBtn) updateBtn.style.display = 'none';
      if(statusEl && d.client_version){
        statusEl.style.color = 'var(--good)';
        statusEl.innerText = '\u2713 Up to date';
      }
    }
    // Sync variant pills to active variant
    if(d.config.variant){
      document.querySelectorAll('.vpill').forEach(p => {
        p.classList.toggle('active', p.textContent.trim() === d.config.variant);
      });
    }

    const bar = document.getElementById('update_progress');
    if(d.stats.busy){
      bar.max = 100;
      bar.value = d.stats.update_progress || 0;
      const spd = d.stats.download_speed || 0;
      const pct = d.stats.update_progress || 0;
      if(spd > 0){
        set('update_progress_text', pct + '%  ·  ' + bytesPerSec(spd));
      } else if(pct > 0){
        set('update_progress_text', pct + '%');
      } else {
        set('update_progress_text', d.stats.current_stage || 'Working...');
      }
    } else {
      const left = d.stats.countdown ?? 0;
      bar.max = d.poll_interval || 60;
      bar.value = (d.poll_interval || 60) - left;
      set('update_progress_text', 'Next check in ' + left + ' sec');
    }
    failCount = 0; // successful response — clear error state
  }catch(e){
    failCount++;
    if(failCount === 3){
      setMsg('Reconnecting...');
    } else if(failCount >= 10){
      const msg = document.getElementById('msg');
      msg.innerHTML = '<span style="color:var(--warn)">&#x26A0; App not responding. <a href="javascript:location.reload()" style="color:var(--accent);text-decoration:underline">Reload</a> once restarted.</span>';
    }
    return;
  }
  failCount = 0;
}

async function saveSettings(){
  const d = await api('/api/ui/save',{backend_url: backendEl.value, mods_folder: modsEl.value});
  setMsg(d.message || 'Done');
  refresh();
}
async function checkNow(){
  const d = await api('/api/ui/check');
  setMsg(d.message || 'Check started');
}
async function repull(){
  const d = await api('/api/ui/repull');
  setMsg(d.message || 'Repull started');
}
async function startListening(){
  const d = await api('/api/ui/listen/start');
  setMsg(d.message || 'Listening started');
  refresh();
}
async function stopListening(){
  const d = await api('/api/ui/listen/stop');
  setMsg(d.message || 'Listening stopped');
  refresh();
}
async function selectFolder(){
  setMsg('Opening folder picker...');
  const d = await api('/api/ui/select-folder');
  if(d.path) modsEl.value = d.path;
  setMsg(d.message || 'Folder selected');
  refresh();
}
async function openLogs(){
  const d = await api('/api/ui/open-logs');
  setMsg(d.message || 'Opening logs');
}
async function registerStartup(){
  const d = await api('/api/ui/register-startup');
  setMsg(d.message || 'Startup registration updated');
  refresh();
}
async function bootstrapClean(){
  const d = await api('/api/ui/bootstrap/clean');
  setMsg(d.message || 'First managed install started');
}
async function bootstrapKeep(){
  const d = await api('/api/ui/bootstrap/keep');
  setMsg(d.message || 'Tracking current folder with first managed install started');
}
async function cancelTask(){
  const d = await api('/api/ui/cancel');
  setMsg(d.message || 'Cancelled');
  refresh();
}

async function checkAppUpdate(){
  const statusEl = document.getElementById('app-update-status');
  if(statusEl){ statusEl.style.color='var(--muted)'; statusEl.innerText='Checking...'; }
  const d = await api('/api/ui/check-app-update');
  setMsg(d.message || 'Checking...');
  // Status will update on next refresh() tick
}

async function doSelfUpdate(){
  const btn = document.getElementById('btn-self-update');
  const statusEl = document.getElementById('app-update-status');
  if(btn){ btn.disabled=true; btn.innerText='Downloading...'; }
  if(statusEl){ statusEl.style.color='var(--muted)'; statusEl.innerText='Downloading update — app will restart shortly...'; }
  setMsg('Downloading update — the app will restart automatically.');
  const d = await api('/api/ui/self-update');
  if(!d.ok){
    if(btn){ btn.disabled=false; btn.innerHTML='\u2B06 Update to v<span id="app-new-ver">'+document.getElementById('app-new-ver').innerText+'</span>'; }
    if(statusEl){ statusEl.style.color='var(--warn)'; statusEl.innerText=d.message||'Update failed'; }
    setMsg(d.message||'Update failed');
  }
}

async function refreshVariants(){
  try{
    const r = await fetch('/api/ui/variants');
    const d = await r.json();
    const pills = document.getElementById('variant-pills');
    const hint  = document.getElementById('variant-hint');
    if(!d.ok || !d.variants || !d.variants.length){
      if(pills) pills.innerHTML = '';
      if(hint)  hint.textContent = 'No variants found on backend.';
      return;
    }
    // Get current active variant
    const statusR = await fetch('/api/ui/status');
    const statusD = await statusR.json();
    const current = statusD.config && statusD.config.variant ? statusD.config.variant : 'default';
    if(hint) hint.textContent = '';
    if(pills){
      pills.innerHTML = d.variants.map(v => {
        const active = v.name === current;
        const dot = v.available_update ? 'background:#22c55e' : 'background:#96a3bd';
        return '<button class="vpill'+(active?' active':'')+'" onclick="setVariant(\''+v.name+'\')">'
          +'<span class="vdot" style="'+dot+'"></span>'+v.name+'</button>';
      }).join('');
    }
  } catch(e){
    const hint = document.getElementById('variant-hint');
    if(hint) hint.textContent = 'Could not reach backend.';
  }
}

async function setVariant(name){
  if(!name) return;
  const d = await api('/api/ui/set-variant', {variant: name});
  setMsg(d.message || 'Variant changed');
  await loadPatchNotes();
  refresh();
}

async function loadPatchNotes(){
  const header = document.getElementById('patch-header');
  const list = document.getElementById('patch-list');
  header.innerText = 'Loading...';
  list.innerHTML = '<div class="patch-empty">Loading...</div>';
  try{
    const r = await fetch('/api/ui/patch-notes');
    const d = await r.json();
    if(!d.ok){ header.innerText = 'Error: ' + (d.message||'unknown'); list.innerHTML=''; return; }

    if(d.is_first){
      header.innerText = 'First update — ' + (d.current_id||'-') + (d.current_time ? '  •  ' + d.current_time : '');
    } else {
      header.innerText = (d.prev_id||'?') + '  →  ' + (d.current_id||'-') + (d.current_time ? '  •  ' + d.current_time : '');
    }

    const entries = d.entries || [];
    if(entries.length === 0){
      list.innerHTML = '<div class="patch-empty">No file changes between last two updates.</div>';
      return;
    }
    entries.sort((a,b)=>{
      if(a.status !== b.status) return a.status === 'removed' ? -1 : 1;
      return a.file.localeCompare(b.file);
    });
    list.innerHTML = entries.map(e => {
      const tag = e.status === 'added'
        ? '<span class="patch-tag added">+ ADDED</span>'
        : '<span class="patch-tag removed">− REMOVED</span>';
      return '<div class="patch-entry ' + e.status + '">' + tag + '<span>' + escHtml(e.file) + '</span></div>';
    }).join('');
  }catch(err){
    header.innerText = 'Failed to load patch notes';
    list.innerHTML = '';
  }
}

function escHtml(s){
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// Load patch notes and variants on startup, then poll status every second
loadPatchNotes();
refreshVariants();
refresh();
setInterval(refresh, 1000);
setInterval(refreshVariants, 30000);
</script>
</body>
</html>
`

