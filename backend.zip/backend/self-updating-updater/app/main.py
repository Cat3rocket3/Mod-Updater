import hashlib, json, os, shutil, tempfile, zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import List

from flask import Flask, jsonify, render_template_string, request, send_file
from werkzeug.utils import secure_filename

DATA_DIR       = Path(os.environ.get("DATA_DIR", "/data"))
DEFAULT_VARIANT = "default"
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024  # 500 MB upload limit


# ── helpers ───────────────────────────────────────────────────────────────────

def now_iso(): return datetime.now(timezone.utc).isoformat()

def load_json(path, default):
    if path.exists():
        try: return json.loads(path.read_text(encoding="utf-8"))
        except: return default
    return default

def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def variant_root(v): return DATA_DIR / "variants" / v

def ensure_variant(v):
    for d in ["staging_mods", "state", "packages"]:
        (variant_root(v) / d).mkdir(parents=True, exist_ok=True)

def list_variants():
    vdir = DATA_DIR / "variants"
    return sorted(p.name for p in vdir.iterdir() if p.is_dir()) if vdir.exists() else []

def v_state(v):    return variant_root(v) / "state" / "state.json"
def v_history(v):  return variant_root(v) / "state" / "history.json"
def v_manifest(v): return variant_root(v) / "state" / "latest_managed_manifest.json"
def v_packages(v): return variant_root(v) / "packages"
def v_staging(v):  return variant_root(v) / "staging_mods"

def load_state(v):
    return load_json(v_state(v), {
        "variant": v, "available_update": False, "latest_update_id": "",
        "latest_created_at": "", "latest_package_name": "", "latest_package_relpath": "",
        "latest_package_size": 0, "latest_file_count": 0, "latest_manifest_name": "",
        "history_count": 0, "last_make_update_result": "Never run",
    })

def save_state(v, s):
    s["history_count"] = len(load_json(v_history(v), []))
    save_json(v_state(v), s)

def iter_staging(v):
    d = v_staging(v)
    return sorted(p for p in d.rglob("*") if p.is_file()) if d.exists() else []

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""): h.update(chunk)
    return h.hexdigest()

def make_update_package(v):
    ensure_variant(v)
    staging = v_staging(v)
    files   = iter_staging(v)
    if not files: raise RuntimeError(f"No files in staging_mods for '{v}'")

    uid  = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    rels = [f.relative_to(staging).as_posix() for f in files]
    items = [{"path": r, "size": f.stat().st_size, "sha256": sha256(f)} for f, r in zip(files, rels)]
    manifest = {"variant": v, "update_id": uid, "created_at": now_iso(), "managed_files": rels, "files": items}

    pkg_name = f"mods_{v}_{uid}.zip"
    pkg_path = v_packages(v) / pkg_name
    mf_name  = f"manifest_{v}_{uid}.json"
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td) / mf_name
        tmp.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        with zipfile.ZipFile(pkg_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(tmp, arcname=mf_name)
            for f, r in zip(files, rels): zf.write(f, arcname=r)

    pkg_size = pkg_path.stat().st_size
    entry = {"variant": v, "update_id": uid, "created_at": now_iso(),
             "package_name": pkg_name, "package_size": pkg_size,
             "file_count": len(files), "managed_files": rels, "manifest_name": mf_name,
             "package_relpath": f"variants/{v}/packages/{pkg_name}"}

    hist = load_json(v_history(v), [])
    hist.insert(0, entry)
    save_json(v_history(v), hist)
    save_json(v_manifest(v), manifest)

    s = load_state(v)
    s.update({"available_update": True, "latest_update_id": uid,
               "latest_created_at": entry["created_at"],
               "latest_package_name": pkg_name,
               "latest_package_relpath": entry["package_relpath"],
               "latest_package_size": pkg_size, "latest_file_count": len(files),
               "latest_manifest_name": mf_name,
               "last_make_update_result": f"Created {uid}"})
    save_state(v, s)
    return entry


# ── Client self-update ────────────────────────────────────────────────────────

CLIENT_DIR = DATA_DIR / "client"

@app.get("/api/client/version")
def api_client_version():
    vf, ef = CLIENT_DIR / "version.txt", CLIENT_DIR / "MinecraftModUpdater.exe"
    if not vf.exists(): return jsonify({"version": "", "available": False, "size": 0})
    ver = vf.read_text(encoding="utf-8").strip()
    return jsonify({"version": ver, "available": ef.exists(), "size": ef.stat().st_size if ef.exists() else 0})

@app.get("/download/client")
def download_client():
    ef = CLIENT_DIR / "MinecraftModUpdater.exe"
    if not ef.exists(): return jsonify({"error": "No client binary"}), 404
    return send_file(ef, mimetype="application/octet-stream", as_attachment=True, download_name="MinecraftModUpdater.exe")

@app.post("/admin/upload-client")
def admin_upload_client():
    version = (request.form.get("version") or "").strip()
    if not version: return jsonify({"ok": False, "error": "version required"}), 400
    if "file" not in request.files: return jsonify({"ok": False, "error": "file required"}), 400
    CLIENT_DIR.mkdir(parents=True, exist_ok=True)
    ef = CLIENT_DIR / "MinecraftModUpdater.exe"
    request.files["file"].save(str(ef))
    (CLIENT_DIR / "version.txt").write_text(version, encoding="utf-8")
    return jsonify({"ok": True, "version": version, "size": ef.stat().st_size})


# ── Variant / Staging API ─────────────────────────────────────────────────────

@app.get("/api/variants")
def api_variants():
    ensure_variant(DEFAULT_VARIANT)
    result = []
    for v in list_variants():
        s = load_state(v)
        result.append({"name": v,
                        "available_update": s.get("available_update", False),
                        "latest_update_id": s.get("latest_update_id", ""),
                        "latest_created_at": s.get("latest_created_at", ""),
                        "latest_file_count": s.get("latest_file_count", 0),
                        "latest_package_size": s.get("latest_package_size", 0),
                        "history_count": s.get("history_count", 0)})
    return jsonify(result)

@app.get("/api/status")
def api_status():
    v = request.args.get("variant", DEFAULT_VARIANT)
    ensure_variant(v)
    s = load_state(v)
    staging_files = iter_staging(v)
    staging_info = [{"name": f.relative_to(v_staging(v)).as_posix(),
                     "size": f.stat().st_size} for f in staging_files]
    return jsonify({
        "variant": v,
        "available_update": s.get("available_update", False),
        "latest_update_id": s.get("latest_update_id", ""),
        "latest_created_at": s.get("latest_created_at", ""),
        "latest_file_count": s.get("latest_file_count", 0),
        "latest_package_size": s.get("latest_package_size", 0),
        "latest_package_name": s.get("latest_package_name", ""),
        "latest_manifest_name": s.get("latest_manifest_name", ""),
        "history_count": len(load_json(v_history(v), [])),
        "staging_file_count": len(staging_files),
        "staging_files": staging_info,
        "last_make_update_result": s.get("last_make_update_result", "Never run"),
    })

@app.get("/api/history")
def api_history():
    v = request.args.get("variant", DEFAULT_VARIANT)
    return jsonify(load_json(v_history(v), []))

@app.get("/api/manifest/latest")
def api_manifest_latest():
    v = request.args.get("variant", DEFAULT_VARIANT)
    mf = v_manifest(v)
    if not mf.exists(): return jsonify({"error": "No manifest available"}), 404
    return send_file(mf, mimetype="application/json")

@app.get("/download/latest")
def download_latest():
    v = request.args.get("variant", DEFAULT_VARIANT)
    s = load_state(v)
    relpath = s.get("latest_package_relpath", "")
    if not relpath: return jsonify({"error": "No package available"}), 404
    pkg = DATA_DIR / relpath
    if not pkg.exists(): return jsonify({"error": "Package file missing"}), 404
    return send_file(pkg, mimetype="application/zip", as_attachment=True, download_name=pkg.name)

@app.post("/admin/make-update")
def admin_make_update():
    payload = request.get_json(silent=True) or {}
    v = payload.get("variant", DEFAULT_VARIANT)
    try:
        entry = make_update_package(v)
        return jsonify({"ok": True, "entry": entry})
    except Exception as exc:
        s = load_state(v); s["last_make_update_result"] = f"Error: {exc}"; save_state(v, s)
        return jsonify({"ok": False, "error": str(exc)}), 400

@app.post("/admin/create-variant")
def admin_create_variant():
    payload = request.get_json(silent=True) or {}
    name = (payload.get("name") or "").strip().lower().replace(" ", "_")
    if not name or any(c in name for c in r"/\."): return jsonify({"ok": False, "error": "Invalid name"}), 400
    ensure_variant(name)
    return jsonify({"ok": True, "variant": name})

@app.post("/admin/delete-variant")
def admin_delete_variant():
    payload = request.get_json(silent=True) or {}
    name = (payload.get("name") or "").strip()
    if not name or name == DEFAULT_VARIANT: return jsonify({"ok": False, "error": "Cannot delete default"}), 400
    vdir = variant_root(name)
    if vdir.exists(): shutil.rmtree(vdir)
    return jsonify({"ok": True})

@app.post("/admin/set-available")
def admin_set_available():
    payload = request.get_json(silent=True) or {}
    v = payload.get("variant", DEFAULT_VARIANT)
    val = bool(payload.get("available", False))
    s = load_state(v); s["available_update"] = val; s["last_make_update_result"] = f"available_update={val}"
    save_state(v, s)
    return jsonify({"ok": True})

@app.post("/admin/upload-mods")
def admin_upload_mods():
    """Upload one or more mod jars directly into a variant's staging_mods."""
    v = request.form.get("variant", DEFAULT_VARIANT)
    ensure_variant(v)
    staging = v_staging(v)
    files = request.files.getlist("files")
    if not files: return jsonify({"ok": False, "error": "No files"}), 400
    saved = []
    for f in files:
        fname = secure_filename(f.filename)
        if not fname: continue
        dest = staging / fname
        f.save(str(dest))
        saved.append({"name": fname, "size": dest.stat().st_size})
    return jsonify({"ok": True, "saved": saved, "count": len(saved)})

@app.post("/admin/delete-staging-file")
def admin_delete_staging_file():
    """Remove a single file from a variant's staging_mods."""
    payload = request.get_json(silent=True) or {}
    v    = payload.get("variant", DEFAULT_VARIANT)
    name = payload.get("name", "")
    if not name or ".." in name: return jsonify({"ok": False, "error": "Invalid filename"}), 400
    target = v_staging(v) / name
    if target.exists() and target.is_file(): target.unlink()
    return jsonify({"ok": True})

@app.post("/admin/clear-staging")
def admin_clear_staging():
    """Remove all files from a variant's staging_mods."""
    payload = request.get_json(silent=True) or {}
    v = payload.get("variant", DEFAULT_VARIANT)
    staging = v_staging(v)
    if staging.exists():
        shutil.rmtree(staging)
        staging.mkdir(parents=True, exist_ok=True)
    return jsonify({"ok": True})

@app.post("/admin/force-stop")
def admin_force_stop():
    import threading, signal as _sig
    def _die():
        import time; time.sleep(0.3); os.kill(os.getpid(), _sig.SIGTERM)
    threading.Thread(target=_die, daemon=True).start()
    return jsonify({"ok": True, "message": "Shutting down..."})


# ── Admin UI ──────────────────────────────────────────────────────────────────

@app.get("/")
def index():
    ensure_variant(DEFAULT_VARIANT)
    return render_template_string(TEMPLATE)


TEMPLATE = r"""<!doctype html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Mod Updater</title>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:Inter,Segoe UI,sans-serif;background:#0d1117;color:#e6edf3;font-size:14px}
    .wrap{max-width:1080px;margin:0 auto;padding:20px 16px}
    .topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
    .topbar h1{font-size:18px;font-weight:700}
    .card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:16px;margin-bottom:14px}
    h2{font-size:11px;font-weight:600;color:#8b949e;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px}
    .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    /* variant tabs */
    .vtabs{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px}
    .vtab{padding:6px 14px;border-radius:8px;border:1px solid #30363d;background:#21262d;
          color:#e6edf3;font-size:13px;font-weight:600;cursor:pointer;transition:.12s;display:flex;align-items:center;gap:6px}
    .vtab:hover{border-color:#58a6ff;color:#58a6ff}
    .vtab.active{background:#1a2e4a;border-color:#1f6feb;color:#58a6ff}
    .vtab .dot{width:6px;height:6px;border-radius:50%}
    .vtab .dot.ok{background:#3fb950}.vtab .dot.no{background:#484f58}
    .new-vtab{display:flex;gap:6px;align-items:center;margin-top:6px}
    /* stats */
    .stat{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #21262d;font-size:13px}
    .stat:last-child{border-bottom:0}
    .mono{font-family:Consolas,monospace;font-size:12px;word-break:break-all;color:#8b949e}
    .pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600}
    .pill.ok{background:#0f4f1a;color:#3fb950}.pill.no{background:#2a1a1a;color:#f85149}
    /* staging */
    .staging-drop{border:2px dashed #30363d;border-radius:10px;padding:20px;text-align:center;
                  color:#8b949e;font-size:13px;cursor:pointer;transition:.15s;margin-bottom:10px}
    .staging-drop.drag{border-color:#1f6feb;background:#0d1f38;color:#58a6ff}
    .staging-drop input{display:none}
    .file-list{display:flex;flex-direction:column;gap:4px;max-height:220px;overflow-y:auto}
    .file-row{display:flex;align-items:center;justify-content:space-between;padding:6px 8px;
              background:#0d1117;border-radius:6px;font-size:12px}
    .file-row .fname{font-family:Consolas,monospace;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .file-row .fsize{color:#8b949e;margin:0 8px;white-space:nowrap}
    .file-row .fdel{color:#f85149;cursor:pointer;font-size:11px;padding:2px 6px;border-radius:4px;border:1px solid #f8514940}
    .file-row .fdel:hover{background:#f8514920}
    /* buttons */
    button{border:0;border-radius:8px;padding:8px 14px;font-weight:600;font-size:13px;cursor:pointer;transition:.12s}
    button:hover{opacity:.85}
    .btn-green{background:#238636;color:#fff}
    .btn-blue{background:#1f6feb;color:#fff}
    .btn-gray{background:#21262d;color:#e6edf3;border:1px solid #30363d}
    .btn-red{background:#b91c1c;color:#fff}
    .btn-sm{padding:5px 10px;font-size:12px}
    .row{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
    input[type=text],input[type=file]{background:#0d1117;border:1px solid #30363d;border-radius:8px;
      padding:7px 10px;color:#e6edf3;font-size:13px;outline:none}
    input:focus{border-color:#388bfd}
    /* history */
    table{width:100%;border-collapse:collapse;font-size:12px;margin-top:8px}
    th{text-align:left;padding:6px;color:#8b949e;border-bottom:1px solid #30363d;font-weight:500}
    td{padding:6px;border-bottom:1px solid #21262d}
    .muted{color:#8b949e}
    .prog{display:none;height:3px;background:#21262d;border-radius:2px;overflow:hidden;margin:8px 0}
    .prog-bar{width:100%;height:100%;background:#388bfd;animation:pulse 1s infinite}
    @keyframes pulse{0%,100%{opacity:.4}50%{opacity:1}}
    .msg-line{font-size:12px;color:#8b949e;min-height:16px;margin-top:4px}
    /* self-update */
    .su-row{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end}
    .su-field{display:flex;flex-direction:column;gap:3px}
    .su-label{font-size:11px;color:#8b949e}
    @media(max-width:700px){.grid2{grid-template-columns:1fr}}
  </style>
</head>
<body>
<div class="wrap">
  <div class="topbar">
    <h1>Mod Updater Backend</h1>
    <button class="btn-red btn-sm" onclick="forceStop()">&#x23F9; Force Stop</button>
  </div>

  <!-- Client EXE Update — prominent card -->
  <div style="background:#161b22;border:2px solid #1f6feb;border-radius:12px;padding:20px;margin-bottom:14px">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
      <div style="background:#1f6feb;border-radius:8px;padding:6px 10px;font-size:13px;font-weight:700;color:#fff">CLIENT UPDATE</div>
      <div>
        <div style="font-size:15px;font-weight:700">Upload New Client EXE</div>
        <div style="font-size:12px;color:#8b949e;margin-top:2px">Clients check this on startup and auto-update when a newer version is available</div>
      </div>
      <div style="margin-left:auto;text-align:right">
        <div style="font-size:11px;color:#8b949e">Currently published</div>
        <div style="font-size:14px;font-weight:700;color:#58a6ff" id="su-ver">Loading...</div>
      </div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
      <div style="display:flex;flex-direction:column;gap:4px;min-width:130px">
        <span style="font-size:11px;color:#8b949e">Version string</span>
        <input type="text" id="su-ver-in" placeholder="e.g. 1.2.0" style="width:100%"/>
      </div>
      <div style="display:flex;flex-direction:column;gap:4px;flex:1;min-width:200px">
        <span style="font-size:11px;color:#8b949e">MinecraftModUpdater.exe file</span>
        <input type="file" id="su-file" accept=".exe" style="width:100%"/>
      </div>
      <button class="btn-blue" id="su-btn" onclick="uploadClient()" style="padding:10px 20px;font-size:14px">&#x2B06; Publish Update</button>
    </div>
    <div id="su-msg" style="margin-top:8px;font-size:13px;color:#8b949e;min-height:18px"></div>
  </div>

  <!-- Variant tabs -->
  <div class="card">
    <h2>Variants</h2>
    <div class="vtabs" id="vtabs"></div>
    <div class="new-vtab">
      <input type="text" id="new-v-input" placeholder="new variant name" style="width:160px"/>
      <button class="btn-green btn-sm" onclick="createVariant()">+ Add variant</button>
    </div>
  </div>

  <!-- Variant detail (shown when a tab is selected) -->
  <div id="vdetail" style="display:none">
    <div class="grid2">
      <!-- Left: staging -->
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <h2 style="margin:0">Staging mods</h2>
          <div class="row">
            <button class="btn-blue btn-sm" onclick="triggerUpload()">+ Upload mods</button>
            <button class="btn-gray btn-sm" onclick="clearStaging()">Clear all</button>
          </div>
        </div>
        <div class="staging-drop" id="staging-drop" onclick="triggerUpload()"
             ondragover="event.preventDefault();this.classList.add('drag')"
             ondragleave="this.classList.remove('drag')"
             ondrop="handleDrop(event)">
          <input type="file" id="staging-file-input" multiple accept=".jar,.zip" onchange="uploadMods(this.files)"/>
          Drop .jar files here or click to upload
        </div>
        <div class="file-list" id="staging-files"></div>
        <div id="staging-prog" class="prog"><div class="prog-bar"></div></div>
        <div id="staging-msg" class="msg-line"></div>
      </div>
      <!-- Right: status + publish -->
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <h2 style="margin:0">Status</h2>
          <div class="row">
            <button class="btn-green btn-sm" id="pub-btn" onclick="makeUpdate()">Publish update</button>
            <button class="btn-gray btn-sm" onclick="setAvail(true)">Set available</button>
            <button class="btn-gray btn-sm" onclick="setAvail(false)">Set unavailable</button>
            <button id="del-btn" class="btn-red btn-sm" style="display:none" onclick="delVariant()">Delete</button>
          </div>
        </div>
        <div id="pub-prog" class="prog"><div class="prog-bar"></div></div>
        <div id="pub-msg" class="msg-line"></div>
        <div id="vstats"></div>
        <h2 style="margin-top:14px">Update history</h2>
        <table><thead><tr><th>Update ID</th><th>Created</th><th>Files</th><th>Size</th></tr></thead>
          <tbody id="vhist"></tbody></table>
      </div>
    </div>
  </div>
</div>
<script>
let variants=[], selected=null;
const B=n=>{n=Number(n||0);if(n<1024)return n+' B';if(n<1048576)return(n/1024).toFixed(1)+' KB';return(n/1048576).toFixed(2)+' MB';};
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
const jpost=(url,body)=>fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})}).then(r=>r.json());

async function loadVariants(){
  variants=await fetch('/api/variants').then(r=>r.json());
  const el=document.getElementById('vtabs');
  el.innerHTML=variants.map(v=>
    '<div class="vtab'+(selected===v.name?' active':'')+'" onclick="selectVariant(\''+esc(v.name)+'\')">'
    +'<div class="dot '+(v.available_update?'ok':'no')+'"></div>'+esc(v.name)+'</div>'
  ).join('');
}

async function selectVariant(name){
  selected=name;
  document.getElementById('vdetail').style.display='block';
  await loadVariants();
  await refreshDetail(name);
}

async function refreshDetail(name){
  const [s,hist]=await Promise.all([
    fetch('/api/status?variant='+encodeURIComponent(name)).then(r=>r.json()),
    fetch('/api/history?variant='+encodeURIComponent(name)).then(r=>r.json()),
  ]);
  const isDef=name==='default';
  document.getElementById('del-btn').style.display=isDef?'none':'';
  // staging files
  const sf=s.staging_files||[];
  document.getElementById('staging-files').innerHTML=sf.length?sf.map(f=>
    '<div class="file-row">'
    +'<span class="fname">'+esc(f.name)+'</span>'
    +'<span class="fsize">'+B(f.size)+'</span>'
    +'<span class="fdel" onclick="delFile(\''+esc(f.name)+'\')">remove</span>'
    +'</div>'
  ).join(''):'<div class="muted" style="font-size:12px;padding:6px">No files in staging.</div>';
  // stats
  document.getElementById('vstats').innerHTML=
    '<div class="stat"><span>Available</span><span class="pill '+(s.available_update?'ok':'no')+'">'+s.available_update+'</span></div>'
    +'<div class="stat"><span>Latest ID</span><span class="mono">'+(s.latest_update_id||'-')+'</span></div>'
    +'<div class="stat"><span>Created</span><span class="mono">'+(s.latest_created_at||'-')+'</span></div>'
    +'<div class="stat"><span>File count</span><span>'+(s.latest_file_count??0)+'</span></div>'
    +'<div class="stat"><span>Package size</span><span>'+B(s.latest_package_size)+'</span></div>'
    +'<div class="stat"><span>Staging files</span><span>'+(s.staging_file_count??0)+'</span></div>'
    +'<div class="stat"><span>Last result</span><span class="mono">'+(s.last_make_update_result||'-')+'</span></div>';
  // history
  document.getElementById('vhist').innerHTML=hist.length?hist.map(h=>
    '<tr><td class="mono">'+esc(h.update_id)+'</td><td class="mono">'+esc(h.created_at||'')+'</td>'
    +'<td>'+h.file_count+'</td><td>'+B(h.package_size)+'</td></tr>'
  ).join(''):'<tr><td colspan="4" class="muted">No history yet</td></tr>';
}

function triggerUpload(){ document.getElementById('staging-file-input').click(); }

function handleDrop(e){
  e.preventDefault();
  document.getElementById('staging-drop').classList.remove('drag');
  uploadMods(e.dataTransfer.files);
}

async function uploadMods(files){
  if(!selected||!files.length) return;
  const fd=new FormData();
  fd.append('variant',selected);
  for(const f of files) fd.append('files',f);
  document.getElementById('staging-prog').style.display='block';
  document.getElementById('staging-msg').textContent='Uploading '+files.length+' file(s)...';
  const r=await fetch('/admin/upload-mods',{method:'POST',body:fd}).then(r=>r.json());
  document.getElementById('staging-prog').style.display='none';
  document.getElementById('staging-msg').textContent=r.ok?'\u2713 Uploaded '+r.count+' file(s)':'\u2717 '+r.error;
  refreshDetail(selected);
}

async function delFile(name){
  await jpost('/admin/delete-staging-file',{variant:selected,name});
  refreshDetail(selected);
}

async function clearStaging(){
  if(!confirm('Remove all staging files for "'+selected+'"?')) return;
  await jpost('/admin/clear-staging',{variant:selected});
  refreshDetail(selected);
}

async function makeUpdate(){
  document.getElementById('pub-prog').style.display='block';
  document.getElementById('pub-msg').textContent='Building...';
  const r=await jpost('/admin/make-update',{variant:selected});
  document.getElementById('pub-prog').style.display='none';
  document.getElementById('pub-msg').textContent=r.ok?'\u2713 '+r.entry.update_id:'\u2717 '+r.error;
  await loadVariants();
  refreshDetail(selected);
}

async function setAvail(v){ await jpost('/admin/set-available',{variant:selected,available:v}); refreshDetail(selected); }

async function createVariant(){
  const name=document.getElementById('new-v-input').value.trim();
  if(!name) return;
  const r=await jpost('/admin/create-variant',{name});
  if(!r.ok){alert(r.error);return;}
  document.getElementById('new-v-input').value='';
  await loadVariants();
  selectVariant(r.variant);
}

async function delVariant(){
  if(!confirm('Delete "'+selected+'" and all its data?')) return;
  await jpost('/admin/delete-variant',{name:selected});
  selected=null;
  document.getElementById('vdetail').style.display='none';
  await loadVariants();
}

async function loadClientVersion(){
  const d=await fetch('/api/client/version').then(r=>r.json());
  document.getElementById('su-ver').textContent=d.available?'v'+d.version+' ('+B(d.size)+')':'None uploaded';
}

async function uploadClient(){
  const ver=document.getElementById('su-ver-in').value.trim();
  const file=document.getElementById('su-file').files[0];
  if(!ver||!file){alert('Version and file required');return;}
  const fd=new FormData(); fd.append('version',ver); fd.append('file',file);
  document.getElementById('su-btn').disabled=true;
  document.getElementById('su-msg').textContent='Uploading...';
  const r=await fetch('/admin/upload-client',{method:'POST',body:fd}).then(r=>r.json());
  document.getElementById('su-btn').disabled=false;
  document.getElementById('su-msg').textContent=r.ok?'\u2713 Published v'+r.version:'\u2717 '+r.error;
  loadClientVersion();
}

async function forceStop(){
  if(!confirm('Force stop the backend?')) return;
  try{await fetch('/admin/force-stop',{method:'POST'});}catch(e){}
  document.body.innerHTML='<div style="text-align:center;padding:80px;color:#8b949e;font-family:sans-serif"><h2 style="color:#e6edf3">Server stopped.</h2></div>';
}

loadClientVersion();
loadVariants().then(()=>{if(variants.length)selectVariant(variants[0].name);});
setInterval(()=>{loadVariants();if(selected)refreshDetail(selected);},8000);
</script>
</body>
</html>"""

if __name__ == "__main__":
    ensure_variant(DEFAULT_VARIANT)
    app.run(host="0.0.0.0", port=8080)
